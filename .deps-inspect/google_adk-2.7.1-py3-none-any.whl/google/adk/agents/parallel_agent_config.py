# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Parallel agent implementation."""

from __future__ import annotations

from pydantic import ConfigDict
from pydantic import Field
from typing_extensions import deprecated

from ..features import experimental
from ..features import FeatureName
from .base_agent_config import BaseAgentConfig


@deprecated(
    "ParallelAgentConfig is deprecated and will be removed in future versions. "
    "Config is now loaded via reflection so the separate config class is no "
    "longer needed."
)
@experimental(FeatureName.AGENT_CONFIG)
class ParallelAgentConfig(BaseAgentConfig):
  """The config for the YAML schema of a ParallelAgent."""

  model_config = ConfigDict(
      extra="forbid",
  )

  agent_class: str = Field(
      default="ParallelAgent",
      description=(
          "The value is used to uniquely identify the ParallelAgent class."
      ),
  )
