# -*- coding: utf-8 -*-

# Copyright 2022 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

from google.cloud.aiplatform.matching_engine.matching_engine_index import (
    MatchingEngineIndex,
)
from google.cloud.aiplatform.matching_engine.matching_engine_index_config import (
    BruteForceConfig as MatchingEngineBruteForceAlgorithmConfig,
    MatchingEngineIndexConfig as MatchingEngineIndexConfig,
    TreeAhConfig as MatchingEngineTreeAhAlgorithmConfig,
)
from google.cloud.aiplatform.matching_engine.matching_engine_index_endpoint import (
    MatchingEngineIndexEndpoint,
)

__all__ = (
    "MatchingEngineIndex",
    "MatchingEngineIndexEndpoint",
    "MatchingEngineIndexConfig",
    "MatchingEngineBruteForceAlgorithmConfig",
    "MatchingEngineTreeAhAlgorithmConfig",
)
