# -*- coding: utf-8 -*-
# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from google.cloud.aiplatform_v1 import gapic_version as package_version

import google.api_core as api_core
import sys

__version__ = package_version.__version__

from importlib import metadata

# PEP 0810: Explicit Lazy Imports
# Python 3.15+ natively intercepts and defers these imports.
# Developers can disable this behavior and force eager imports.
# For more information, see:
# https://docs.python.org/3.15/library/sys.html#sys.set_lazy_imports_filter
# Older Python versions safely ignore this variable.
__lazy_modules__ = {
    "google.cloud.aiplatform_v1.services.data_foundry_service",
    "google.cloud.aiplatform_v1.services.dataset_service",
    "google.cloud.aiplatform_v1.services.deployment_resource_pool_service",
    "google.cloud.aiplatform_v1.services.endpoint_service",
    "google.cloud.aiplatform_v1.services.evaluation_service",
    "google.cloud.aiplatform_v1.services.feature_online_store_admin_service",
    "google.cloud.aiplatform_v1.services.feature_online_store_service",
    "google.cloud.aiplatform_v1.services.feature_registry_service",
    "google.cloud.aiplatform_v1.services.featurestore_online_serving_service",
    "google.cloud.aiplatform_v1.services.featurestore_service",
    "google.cloud.aiplatform_v1.services.gen_ai_cache_service",
    "google.cloud.aiplatform_v1.services.gen_ai_tuning_service",
    "google.cloud.aiplatform_v1.services.index_endpoint_service",
    "google.cloud.aiplatform_v1.services.index_service",
    "google.cloud.aiplatform_v1.services.job_service",
    "google.cloud.aiplatform_v1.services.llm_utility_service",
    "google.cloud.aiplatform_v1.services.match_service",
    "google.cloud.aiplatform_v1.services.metadata_service",
    "google.cloud.aiplatform_v1.services.migration_service",
    "google.cloud.aiplatform_v1.services.model_garden_service",
    "google.cloud.aiplatform_v1.services.model_service",
    "google.cloud.aiplatform_v1.services.notebook_service",
    "google.cloud.aiplatform_v1.services.persistent_resource_service",
    "google.cloud.aiplatform_v1.services.pipeline_service",
    "google.cloud.aiplatform_v1.services.prediction_service",
    "google.cloud.aiplatform_v1.services.reasoning_engine_execution_service",
    "google.cloud.aiplatform_v1.services.reasoning_engine_service",
    "google.cloud.aiplatform_v1.services.schedule_service",
    "google.cloud.aiplatform_v1.services.session_service",
    "google.cloud.aiplatform_v1.services.specialist_pool_service",
    "google.cloud.aiplatform_v1.services.tensorboard_service",
    "google.cloud.aiplatform_v1.services.vertex_rag_data_service",
    "google.cloud.aiplatform_v1.services.vertex_rag_service",
    "google.cloud.aiplatform_v1.services.vizier_service",
    "google.cloud.aiplatform_v1.types.accelerator_type",
    "google.cloud.aiplatform_v1.types.annotation",
    "google.cloud.aiplatform_v1.types.annotation_spec",
    "google.cloud.aiplatform_v1.types.api_auth",
    "google.cloud.aiplatform_v1.types.artifact",
    "google.cloud.aiplatform_v1.types.batch_prediction_job",
    "google.cloud.aiplatform_v1.types.cached_content",
    "google.cloud.aiplatform_v1.types.completion_stats",
    "google.cloud.aiplatform_v1.types.content",
    "google.cloud.aiplatform_v1.types.context",
    "google.cloud.aiplatform_v1.types.custom_job",
    "google.cloud.aiplatform_v1.types.data_foundry_service",
    "google.cloud.aiplatform_v1.types.data_item",
    "google.cloud.aiplatform_v1.types.data_labeling_job",
    "google.cloud.aiplatform_v1.types.dataset",
    "google.cloud.aiplatform_v1.types.dataset_service",
    "google.cloud.aiplatform_v1.types.dataset_version",
    "google.cloud.aiplatform_v1.types.deployed_index_ref",
    "google.cloud.aiplatform_v1.types.deployed_model_ref",
    "google.cloud.aiplatform_v1.types.deployment_resource_pool",
    "google.cloud.aiplatform_v1.types.deployment_resource_pool_service",
    "google.cloud.aiplatform_v1.types.deployment_stage",
    "google.cloud.aiplatform_v1.types.encryption_spec",
    "google.cloud.aiplatform_v1.types.endpoint",
    "google.cloud.aiplatform_v1.types.endpoint_service",
    "google.cloud.aiplatform_v1.types.entity_type",
    "google.cloud.aiplatform_v1.types.env_var",
    "google.cloud.aiplatform_v1.types.evaluated_annotation",
    "google.cloud.aiplatform_v1.types.evaluation_service",
    "google.cloud.aiplatform_v1.types.event",
    "google.cloud.aiplatform_v1.types.execution",
    "google.cloud.aiplatform_v1.types.explanation",
    "google.cloud.aiplatform_v1.types.explanation_metadata",
    "google.cloud.aiplatform_v1.types.feature",
    "google.cloud.aiplatform_v1.types.feature_group",
    "google.cloud.aiplatform_v1.types.feature_monitoring_stats",
    "google.cloud.aiplatform_v1.types.feature_online_store",
    "google.cloud.aiplatform_v1.types.feature_online_store_admin_service",
    "google.cloud.aiplatform_v1.types.feature_online_store_service",
    "google.cloud.aiplatform_v1.types.feature_registry_service",
    "google.cloud.aiplatform_v1.types.feature_selector",
    "google.cloud.aiplatform_v1.types.feature_view",
    "google.cloud.aiplatform_v1.types.feature_view_sync",
    "google.cloud.aiplatform_v1.types.featurestore",
    "google.cloud.aiplatform_v1.types.featurestore_monitoring",
    "google.cloud.aiplatform_v1.types.featurestore_online_service",
    "google.cloud.aiplatform_v1.types.featurestore_service",
    "google.cloud.aiplatform_v1.types.gen_ai_cache_service",
    "google.cloud.aiplatform_v1.types.genai_tuning_service",
    "google.cloud.aiplatform_v1.types.hyperparameter_tuning_job",
    "google.cloud.aiplatform_v1.types.index",
    "google.cloud.aiplatform_v1.types.index_endpoint",
    "google.cloud.aiplatform_v1.types.index_endpoint_service",
    "google.cloud.aiplatform_v1.types.index_service",
    "google.cloud.aiplatform_v1.types.io",
    "google.cloud.aiplatform_v1.types.job_service",
    "google.cloud.aiplatform_v1.types.job_state",
    "google.cloud.aiplatform_v1.types.lineage_subgraph",
    "google.cloud.aiplatform_v1.types.llm_utility_service",
    "google.cloud.aiplatform_v1.types.machine_resources",
    "google.cloud.aiplatform_v1.types.manual_batch_tuning_parameters",
    "google.cloud.aiplatform_v1.types.match_service",
    "google.cloud.aiplatform_v1.types.metadata_schema",
    "google.cloud.aiplatform_v1.types.metadata_service",
    "google.cloud.aiplatform_v1.types.metadata_store",
    "google.cloud.aiplatform_v1.types.migratable_resource",
    "google.cloud.aiplatform_v1.types.migration_service",
    "google.cloud.aiplatform_v1.types.model",
    "google.cloud.aiplatform_v1.types.model_deployment_monitoring_job",
    "google.cloud.aiplatform_v1.types.model_evaluation",
    "google.cloud.aiplatform_v1.types.model_evaluation_slice",
    "google.cloud.aiplatform_v1.types.model_garden_service",
    "google.cloud.aiplatform_v1.types.model_monitoring",
    "google.cloud.aiplatform_v1.types.model_service",
    "google.cloud.aiplatform_v1.types.nas_job",
    "google.cloud.aiplatform_v1.types.network_spec",
    "google.cloud.aiplatform_v1.types.notebook_euc_config",
    "google.cloud.aiplatform_v1.types.notebook_execution_job",
    "google.cloud.aiplatform_v1.types.notebook_idle_shutdown_config",
    "google.cloud.aiplatform_v1.types.notebook_runtime",
    "google.cloud.aiplatform_v1.types.notebook_runtime_template_ref",
    "google.cloud.aiplatform_v1.types.notebook_service",
    "google.cloud.aiplatform_v1.types.notebook_software_config",
    "google.cloud.aiplatform_v1.types.openapi",
    "google.cloud.aiplatform_v1.types.operation",
    "google.cloud.aiplatform_v1.types.persistent_resource",
    "google.cloud.aiplatform_v1.types.persistent_resource_service",
    "google.cloud.aiplatform_v1.types.pipeline_failure_policy",
    "google.cloud.aiplatform_v1.types.pipeline_job",
    "google.cloud.aiplatform_v1.types.pipeline_service",
    "google.cloud.aiplatform_v1.types.pipeline_state",
    "google.cloud.aiplatform_v1.types.prediction_service",
    "google.cloud.aiplatform_v1.types.publisher_model",
    "google.cloud.aiplatform_v1.types.reasoning_engine",
    "google.cloud.aiplatform_v1.types.reasoning_engine_execution_service",
    "google.cloud.aiplatform_v1.types.reasoning_engine_service",
    "google.cloud.aiplatform_v1.types.reservation_affinity",
    "google.cloud.aiplatform_v1.types.saved_query",
    "google.cloud.aiplatform_v1.types.schedule",
    "google.cloud.aiplatform_v1.types.schedule_service",
    "google.cloud.aiplatform_v1.types.service_networking",
    "google.cloud.aiplatform_v1.types.session",
    "google.cloud.aiplatform_v1.types.session_service",
    "google.cloud.aiplatform_v1.types.specialist_pool",
    "google.cloud.aiplatform_v1.types.specialist_pool_service",
    "google.cloud.aiplatform_v1.types.study",
    "google.cloud.aiplatform_v1.types.tensorboard",
    "google.cloud.aiplatform_v1.types.tensorboard_data",
    "google.cloud.aiplatform_v1.types.tensorboard_experiment",
    "google.cloud.aiplatform_v1.types.tensorboard_run",
    "google.cloud.aiplatform_v1.types.tensorboard_service",
    "google.cloud.aiplatform_v1.types.tensorboard_time_series",
    "google.cloud.aiplatform_v1.types.tool",
    "google.cloud.aiplatform_v1.types.training_pipeline",
    "google.cloud.aiplatform_v1.types.tuning_job",
    "google.cloud.aiplatform_v1.types.types",
    "google.cloud.aiplatform_v1.types.unmanaged_container_model",
    "google.cloud.aiplatform_v1.types.usage_metadata",
    "google.cloud.aiplatform_v1.types.user_action_reference",
    "google.cloud.aiplatform_v1.types.value",
    "google.cloud.aiplatform_v1.types.vertex_rag_data",
    "google.cloud.aiplatform_v1.types.vertex_rag_data_service",
    "google.cloud.aiplatform_v1.types.vertex_rag_service",
    "google.cloud.aiplatform_v1.types.vizier_service",
}


from .services.data_foundry_service import DataFoundryServiceClient
from .services.data_foundry_service import DataFoundryServiceAsyncClient
from .services.dataset_service import DatasetServiceClient
from .services.dataset_service import DatasetServiceAsyncClient
from .services.deployment_resource_pool_service import (
    DeploymentResourcePoolServiceClient,
)
from .services.deployment_resource_pool_service import (
    DeploymentResourcePoolServiceAsyncClient,
)
from .services.endpoint_service import EndpointServiceClient
from .services.endpoint_service import EndpointServiceAsyncClient
from .services.evaluation_service import EvaluationServiceClient
from .services.evaluation_service import EvaluationServiceAsyncClient
from .services.feature_online_store_admin_service import (
    FeatureOnlineStoreAdminServiceClient,
)
from .services.feature_online_store_admin_service import (
    FeatureOnlineStoreAdminServiceAsyncClient,
)
from .services.feature_online_store_service import FeatureOnlineStoreServiceClient
from .services.feature_online_store_service import FeatureOnlineStoreServiceAsyncClient
from .services.feature_registry_service import FeatureRegistryServiceClient
from .services.feature_registry_service import FeatureRegistryServiceAsyncClient
from .services.featurestore_online_serving_service import (
    FeaturestoreOnlineServingServiceClient,
)
from .services.featurestore_online_serving_service import (
    FeaturestoreOnlineServingServiceAsyncClient,
)
from .services.featurestore_service import FeaturestoreServiceClient
from .services.featurestore_service import FeaturestoreServiceAsyncClient
from .services.gen_ai_cache_service import GenAiCacheServiceClient
from .services.gen_ai_cache_service import GenAiCacheServiceAsyncClient
from .services.gen_ai_tuning_service import GenAiTuningServiceClient
from .services.gen_ai_tuning_service import GenAiTuningServiceAsyncClient
from .services.index_endpoint_service import IndexEndpointServiceClient
from .services.index_endpoint_service import IndexEndpointServiceAsyncClient
from .services.index_service import IndexServiceClient
from .services.index_service import IndexServiceAsyncClient
from .services.job_service import JobServiceClient
from .services.job_service import JobServiceAsyncClient
from .services.llm_utility_service import LlmUtilityServiceClient
from .services.llm_utility_service import LlmUtilityServiceAsyncClient
from .services.match_service import MatchServiceClient
from .services.match_service import MatchServiceAsyncClient
from .services.metadata_service import MetadataServiceClient
from .services.metadata_service import MetadataServiceAsyncClient
from .services.migration_service import MigrationServiceClient
from .services.migration_service import MigrationServiceAsyncClient
from .services.model_garden_service import ModelGardenServiceClient
from .services.model_garden_service import ModelGardenServiceAsyncClient
from .services.model_service import ModelServiceClient
from .services.model_service import ModelServiceAsyncClient
from .services.notebook_service import NotebookServiceClient
from .services.notebook_service import NotebookServiceAsyncClient
from .services.persistent_resource_service import PersistentResourceServiceClient
from .services.persistent_resource_service import PersistentResourceServiceAsyncClient
from .services.pipeline_service import PipelineServiceClient
from .services.pipeline_service import PipelineServiceAsyncClient
from .services.prediction_service import PredictionServiceClient
from .services.prediction_service import PredictionServiceAsyncClient
from .services.reasoning_engine_execution_service import (
    ReasoningEngineExecutionServiceClient,
)
from .services.reasoning_engine_execution_service import (
    ReasoningEngineExecutionServiceAsyncClient,
)
from .services.reasoning_engine_service import ReasoningEngineServiceClient
from .services.reasoning_engine_service import ReasoningEngineServiceAsyncClient
from .services.schedule_service import ScheduleServiceClient
from .services.schedule_service import ScheduleServiceAsyncClient
from .services.session_service import SessionServiceClient
from .services.session_service import SessionServiceAsyncClient
from .services.specialist_pool_service import SpecialistPoolServiceClient
from .services.specialist_pool_service import SpecialistPoolServiceAsyncClient
from .services.tensorboard_service import TensorboardServiceClient
from .services.tensorboard_service import TensorboardServiceAsyncClient
from .services.vertex_rag_data_service import VertexRagDataServiceClient
from .services.vertex_rag_data_service import VertexRagDataServiceAsyncClient
from .services.vertex_rag_service import VertexRagServiceClient
from .services.vertex_rag_service import VertexRagServiceAsyncClient
from .services.vizier_service import VizierServiceClient
from .services.vizier_service import VizierServiceAsyncClient

from .types.accelerator_type import AcceleratorType
from .types.annotation import Annotation
from .types.annotation_spec import AnnotationSpec
from .types.api_auth import ApiAuth
from .types.artifact import Artifact
from .types.batch_prediction_job import BatchPredictionJob
from .types.cached_content import CachedContent
from .types.completion_stats import CompletionStats
from .types.content import Blob
from .types.content import Candidate
from .types.content import Citation
from .types.content import CitationMetadata
from .types.content import Content
from .types.content import FileData
from .types.content import GenerationConfig
from .types.content import GroundingChunk
from .types.content import GroundingMetadata
from .types.content import GroundingSupport
from .types.content import ImageConfig
from .types.content import LogprobsResult
from .types.content import ModalityTokenCount
from .types.content import ModelArmorConfig
from .types.content import MultiSpeakerVoiceConfig
from .types.content import Part
from .types.content import PrebuiltVoiceConfig
from .types.content import ReplicatedVoiceConfig
from .types.content import RetrievalMetadata
from .types.content import SafetyRating
from .types.content import SafetySetting
from .types.content import SearchEntryPoint
from .types.content import Segment
from .types.content import SpeakerVoiceConfig
from .types.content import SpeechConfig
from .types.content import UrlContextMetadata
from .types.content import UrlMetadata
from .types.content import VideoMetadata
from .types.content import VoiceConfig
from .types.content import HarmCategory
from .types.content import Modality
from .types.context import Context
from .types.custom_job import ContainerSpec
from .types.custom_job import CustomJob
from .types.custom_job import CustomJobSpec
from .types.custom_job import PythonPackageSpec
from .types.custom_job import Scheduling
from .types.custom_job import WorkerPoolSpec
from .types.data_foundry_service import GenerateSyntheticDataRequest
from .types.data_foundry_service import GenerateSyntheticDataResponse
from .types.data_foundry_service import OutputFieldSpec
from .types.data_foundry_service import SyntheticExample
from .types.data_foundry_service import SyntheticField
from .types.data_foundry_service import TaskDescriptionStrategy
from .types.data_item import DataItem
from .types.data_labeling_job import ActiveLearningConfig
from .types.data_labeling_job import DataLabelingJob
from .types.data_labeling_job import SampleConfig
from .types.data_labeling_job import TrainingConfig
from .types.dataset import Dataset
from .types.dataset import ExportDataConfig
from .types.dataset import ExportFilterSplit
from .types.dataset import ExportFractionSplit
from .types.dataset import ImportDataConfig
from .types.dataset_service import CreateDatasetOperationMetadata
from .types.dataset_service import CreateDatasetRequest
from .types.dataset_service import CreateDatasetVersionOperationMetadata
from .types.dataset_service import CreateDatasetVersionRequest
from .types.dataset_service import DataItemView
from .types.dataset_service import DeleteDatasetRequest
from .types.dataset_service import DeleteDatasetVersionRequest
from .types.dataset_service import DeleteSavedQueryRequest
from .types.dataset_service import ExportDataOperationMetadata
from .types.dataset_service import ExportDataRequest
from .types.dataset_service import ExportDataResponse
from .types.dataset_service import GetAnnotationSpecRequest
from .types.dataset_service import GetDatasetRequest
from .types.dataset_service import GetDatasetVersionRequest
from .types.dataset_service import ImportDataOperationMetadata
from .types.dataset_service import ImportDataRequest
from .types.dataset_service import ImportDataResponse
from .types.dataset_service import ListAnnotationsRequest
from .types.dataset_service import ListAnnotationsResponse
from .types.dataset_service import ListDataItemsRequest
from .types.dataset_service import ListDataItemsResponse
from .types.dataset_service import ListDatasetsRequest
from .types.dataset_service import ListDatasetsResponse
from .types.dataset_service import ListDatasetVersionsRequest
from .types.dataset_service import ListDatasetVersionsResponse
from .types.dataset_service import ListSavedQueriesRequest
from .types.dataset_service import ListSavedQueriesResponse
from .types.dataset_service import RestoreDatasetVersionOperationMetadata
from .types.dataset_service import RestoreDatasetVersionRequest
from .types.dataset_service import SearchDataItemsRequest
from .types.dataset_service import SearchDataItemsResponse
from .types.dataset_service import UpdateDatasetRequest
from .types.dataset_service import UpdateDatasetVersionRequest
from .types.dataset_version import DatasetVersion
from .types.deployed_index_ref import DeployedIndexRef
from .types.deployed_model_ref import DeployedModelRef
from .types.deployment_resource_pool import DeploymentResourcePool
from .types.deployment_resource_pool_service import (
    CreateDeploymentResourcePoolOperationMetadata,
)
from .types.deployment_resource_pool_service import CreateDeploymentResourcePoolRequest
from .types.deployment_resource_pool_service import DeleteDeploymentResourcePoolRequest
from .types.deployment_resource_pool_service import GetDeploymentResourcePoolRequest
from .types.deployment_resource_pool_service import ListDeploymentResourcePoolsRequest
from .types.deployment_resource_pool_service import ListDeploymentResourcePoolsResponse
from .types.deployment_resource_pool_service import QueryDeployedModelsRequest
from .types.deployment_resource_pool_service import QueryDeployedModelsResponse
from .types.deployment_resource_pool_service import (
    UpdateDeploymentResourcePoolOperationMetadata,
)
from .types.deployment_resource_pool_service import UpdateDeploymentResourcePoolRequest
from .types.deployment_stage import DeploymentStage
from .types.encryption_spec import EncryptionSpec
from .types.endpoint import ClientConnectionConfig
from .types.endpoint import DeployedModel
from .types.endpoint import Endpoint
from .types.endpoint import FasterDeploymentConfig
from .types.endpoint import GenAiAdvancedFeaturesConfig
from .types.endpoint import PredictRequestResponseLoggingConfig
from .types.endpoint import PrivateEndpoints
from .types.endpoint import SpeculativeDecodingSpec
from .types.endpoint_service import CreateEndpointOperationMetadata
from .types.endpoint_service import CreateEndpointRequest
from .types.endpoint_service import DeleteEndpointRequest
from .types.endpoint_service import DeployModelOperationMetadata
from .types.endpoint_service import DeployModelRequest
from .types.endpoint_service import DeployModelResponse
from .types.endpoint_service import GetEndpointRequest
from .types.endpoint_service import ListEndpointsRequest
from .types.endpoint_service import ListEndpointsResponse
from .types.endpoint_service import MutateDeployedModelOperationMetadata
from .types.endpoint_service import MutateDeployedModelRequest
from .types.endpoint_service import MutateDeployedModelResponse
from .types.endpoint_service import UndeployModelOperationMetadata
from .types.endpoint_service import UndeployModelRequest
from .types.endpoint_service import UndeployModelResponse
from .types.endpoint_service import UpdateEndpointLongRunningRequest
from .types.endpoint_service import UpdateEndpointOperationMetadata
from .types.endpoint_service import UpdateEndpointRequest
from .types.entity_type import EntityType
from .types.env_var import EnvVar
from .types.env_var import SecretEnvVar
from .types.env_var import SecretRef
from .types.evaluated_annotation import ErrorAnalysisAnnotation
from .types.evaluated_annotation import EvaluatedAnnotation
from .types.evaluated_annotation import EvaluatedAnnotationExplanation
from .types.evaluation_service import AggregationOutput
from .types.evaluation_service import AggregationResult
from .types.evaluation_service import AutoraterConfig
from .types.evaluation_service import BleuInput
from .types.evaluation_service import BleuInstance
from .types.evaluation_service import BleuMetricValue
from .types.evaluation_service import BleuResults
from .types.evaluation_service import BleuSpec
from .types.evaluation_service import CoherenceInput
from .types.evaluation_service import CoherenceInstance
from .types.evaluation_service import CoherenceResult
from .types.evaluation_service import CoherenceSpec
from .types.evaluation_service import CometInput
from .types.evaluation_service import CometInstance
from .types.evaluation_service import CometResult
from .types.evaluation_service import CometSpec
from .types.evaluation_service import ComputationBasedMetricSpec
from .types.evaluation_service import ContentMap
from .types.evaluation_service import CustomOutput
from .types.evaluation_service import CustomOutputFormatConfig
from .types.evaluation_service import EvaluateDatasetResponse
from .types.evaluation_service import EvaluateInstancesRequest
from .types.evaluation_service import EvaluateInstancesResponse
from .types.evaluation_service import EvaluationDataset
from .types.evaluation_service import ExactMatchInput
from .types.evaluation_service import ExactMatchInstance
from .types.evaluation_service import ExactMatchMetricValue
from .types.evaluation_service import ExactMatchResults
from .types.evaluation_service import ExactMatchSpec
from .types.evaluation_service import FluencyInput
from .types.evaluation_service import FluencyInstance
from .types.evaluation_service import FluencyResult
from .types.evaluation_service import FluencySpec
from .types.evaluation_service import FulfillmentInput
from .types.evaluation_service import FulfillmentInstance
from .types.evaluation_service import FulfillmentResult
from .types.evaluation_service import FulfillmentSpec
from .types.evaluation_service import GroundednessInput
from .types.evaluation_service import GroundednessInstance
from .types.evaluation_service import GroundednessResult
from .types.evaluation_service import GroundednessSpec
from .types.evaluation_service import LLMBasedMetricSpec
from .types.evaluation_service import Metric
from .types.evaluation_service import MetricResult
from .types.evaluation_service import MetricxInput
from .types.evaluation_service import MetricxInstance
from .types.evaluation_service import MetricxResult
from .types.evaluation_service import MetricxSpec
from .types.evaluation_service import OutputConfig
from .types.evaluation_service import OutputInfo
from .types.evaluation_service import PairwiseMetricInput
from .types.evaluation_service import PairwiseMetricInstance
from .types.evaluation_service import PairwiseMetricResult
from .types.evaluation_service import PairwiseMetricSpec
from .types.evaluation_service import PairwiseQuestionAnsweringQualityInput
from .types.evaluation_service import PairwiseQuestionAnsweringQualityInstance
from .types.evaluation_service import PairwiseQuestionAnsweringQualityResult
from .types.evaluation_service import PairwiseQuestionAnsweringQualitySpec
from .types.evaluation_service import PairwiseSummarizationQualityInput
from .types.evaluation_service import PairwiseSummarizationQualityInstance
from .types.evaluation_service import PairwiseSummarizationQualityResult
from .types.evaluation_service import PairwiseSummarizationQualitySpec
from .types.evaluation_service import PointwiseMetricInput
from .types.evaluation_service import PointwiseMetricInstance
from .types.evaluation_service import PointwiseMetricResult
from .types.evaluation_service import PointwiseMetricSpec
from .types.evaluation_service import PredefinedMetricSpec
from .types.evaluation_service import QuestionAnsweringCorrectnessInput
from .types.evaluation_service import QuestionAnsweringCorrectnessInstance
from .types.evaluation_service import QuestionAnsweringCorrectnessResult
from .types.evaluation_service import QuestionAnsweringCorrectnessSpec
from .types.evaluation_service import QuestionAnsweringHelpfulnessInput
from .types.evaluation_service import QuestionAnsweringHelpfulnessInstance
from .types.evaluation_service import QuestionAnsweringHelpfulnessResult
from .types.evaluation_service import QuestionAnsweringHelpfulnessSpec
from .types.evaluation_service import QuestionAnsweringQualityInput
from .types.evaluation_service import QuestionAnsweringQualityInstance
from .types.evaluation_service import QuestionAnsweringQualityResult
from .types.evaluation_service import QuestionAnsweringQualitySpec
from .types.evaluation_service import QuestionAnsweringRelevanceInput
from .types.evaluation_service import QuestionAnsweringRelevanceInstance
from .types.evaluation_service import QuestionAnsweringRelevanceResult
from .types.evaluation_service import QuestionAnsweringRelevanceSpec
from .types.evaluation_service import RawOutput
from .types.evaluation_service import RougeInput
from .types.evaluation_service import RougeInstance
from .types.evaluation_service import RougeMetricValue
from .types.evaluation_service import RougeResults
from .types.evaluation_service import RougeSpec
from .types.evaluation_service import SafetyInput
from .types.evaluation_service import SafetyInstance
from .types.evaluation_service import SafetyResult
from .types.evaluation_service import SafetySpec
from .types.evaluation_service import SummarizationHelpfulnessInput
from .types.evaluation_service import SummarizationHelpfulnessInstance
from .types.evaluation_service import SummarizationHelpfulnessResult
from .types.evaluation_service import SummarizationHelpfulnessSpec
from .types.evaluation_service import SummarizationQualityInput
from .types.evaluation_service import SummarizationQualityInstance
from .types.evaluation_service import SummarizationQualityResult
from .types.evaluation_service import SummarizationQualitySpec
from .types.evaluation_service import SummarizationVerbosityInput
from .types.evaluation_service import SummarizationVerbosityInstance
from .types.evaluation_service import SummarizationVerbosityResult
from .types.evaluation_service import SummarizationVerbositySpec
from .types.evaluation_service import ToolCallValidInput
from .types.evaluation_service import ToolCallValidInstance
from .types.evaluation_service import ToolCallValidMetricValue
from .types.evaluation_service import ToolCallValidResults
from .types.evaluation_service import ToolCallValidSpec
from .types.evaluation_service import ToolNameMatchInput
from .types.evaluation_service import ToolNameMatchInstance
from .types.evaluation_service import ToolNameMatchMetricValue
from .types.evaluation_service import ToolNameMatchResults
from .types.evaluation_service import ToolNameMatchSpec
from .types.evaluation_service import ToolParameterKeyMatchInput
from .types.evaluation_service import ToolParameterKeyMatchInstance
from .types.evaluation_service import ToolParameterKeyMatchMetricValue
from .types.evaluation_service import ToolParameterKeyMatchResults
from .types.evaluation_service import ToolParameterKeyMatchSpec
from .types.evaluation_service import ToolParameterKVMatchInput
from .types.evaluation_service import ToolParameterKVMatchInstance
from .types.evaluation_service import ToolParameterKVMatchMetricValue
from .types.evaluation_service import ToolParameterKVMatchResults
from .types.evaluation_service import ToolParameterKVMatchSpec
from .types.evaluation_service import PairwiseChoice
from .types.event import Event
from .types.execution import Execution
from .types.explanation import Attribution
from .types.explanation import BlurBaselineConfig
from .types.explanation import Examples
from .types.explanation import ExamplesOverride
from .types.explanation import ExamplesRestrictionsNamespace
from .types.explanation import Explanation
from .types.explanation import ExplanationMetadataOverride
from .types.explanation import ExplanationParameters
from .types.explanation import ExplanationSpec
from .types.explanation import ExplanationSpecOverride
from .types.explanation import FeatureNoiseSigma
from .types.explanation import IntegratedGradientsAttribution
from .types.explanation import ModelExplanation
from .types.explanation import Neighbor
from .types.explanation import Presets
from .types.explanation import SampledShapleyAttribution
from .types.explanation import SmoothGradConfig
from .types.explanation import XraiAttribution
from .types.explanation_metadata import ExplanationMetadata
from .types.feature import Feature
from .types.feature_group import FeatureGroup
from .types.feature_monitoring_stats import FeatureStatsAnomaly
from .types.feature_online_store import FeatureOnlineStore
from .types.feature_online_store_admin_service import (
    CreateFeatureOnlineStoreOperationMetadata,
)
from .types.feature_online_store_admin_service import CreateFeatureOnlineStoreRequest
from .types.feature_online_store_admin_service import CreateFeatureViewOperationMetadata
from .types.feature_online_store_admin_service import CreateFeatureViewRequest
from .types.feature_online_store_admin_service import DeleteFeatureOnlineStoreRequest
from .types.feature_online_store_admin_service import DeleteFeatureViewRequest
from .types.feature_online_store_admin_service import GetFeatureOnlineStoreRequest
from .types.feature_online_store_admin_service import GetFeatureViewRequest
from .types.feature_online_store_admin_service import GetFeatureViewSyncRequest
from .types.feature_online_store_admin_service import ListFeatureOnlineStoresRequest
from .types.feature_online_store_admin_service import ListFeatureOnlineStoresResponse
from .types.feature_online_store_admin_service import ListFeatureViewsRequest
from .types.feature_online_store_admin_service import ListFeatureViewsResponse
from .types.feature_online_store_admin_service import ListFeatureViewSyncsRequest
from .types.feature_online_store_admin_service import ListFeatureViewSyncsResponse
from .types.feature_online_store_admin_service import SyncFeatureViewRequest
from .types.feature_online_store_admin_service import SyncFeatureViewResponse
from .types.feature_online_store_admin_service import (
    UpdateFeatureOnlineStoreOperationMetadata,
)
from .types.feature_online_store_admin_service import UpdateFeatureOnlineStoreRequest
from .types.feature_online_store_admin_service import UpdateFeatureViewOperationMetadata
from .types.feature_online_store_admin_service import UpdateFeatureViewRequest
from .types.feature_online_store_service import FeatureViewDataKey
from .types.feature_online_store_service import FeatureViewDirectWriteRequest
from .types.feature_online_store_service import FeatureViewDirectWriteResponse
from .types.feature_online_store_service import FetchFeatureValuesRequest
from .types.feature_online_store_service import FetchFeatureValuesResponse
from .types.feature_online_store_service import GenerateFetchAccessTokenRequest
from .types.feature_online_store_service import GenerateFetchAccessTokenResponse
from .types.feature_online_store_service import NearestNeighborQuery
from .types.feature_online_store_service import NearestNeighbors
from .types.feature_online_store_service import SearchNearestEntitiesRequest
from .types.feature_online_store_service import SearchNearestEntitiesResponse
from .types.feature_online_store_service import FeatureViewDataFormat
from .types.feature_registry_service import CreateFeatureGroupOperationMetadata
from .types.feature_registry_service import CreateFeatureGroupRequest
from .types.feature_registry_service import CreateRegistryFeatureOperationMetadata
from .types.feature_registry_service import DeleteFeatureGroupRequest
from .types.feature_registry_service import GetFeatureGroupRequest
from .types.feature_registry_service import ListFeatureGroupsRequest
from .types.feature_registry_service import ListFeatureGroupsResponse
from .types.feature_registry_service import UpdateFeatureGroupOperationMetadata
from .types.feature_registry_service import UpdateFeatureGroupRequest
from .types.feature_registry_service import UpdateFeatureOperationMetadata
from .types.feature_selector import FeatureSelector
from .types.feature_selector import IdMatcher
from .types.feature_view import FeatureView
from .types.feature_view_sync import FeatureViewSync
from .types.featurestore import Featurestore
from .types.featurestore_monitoring import FeaturestoreMonitoringConfig
from .types.featurestore_online_service import FeatureValue
from .types.featurestore_online_service import FeatureValueList
from .types.featurestore_online_service import ReadFeatureValuesRequest
from .types.featurestore_online_service import ReadFeatureValuesResponse
from .types.featurestore_online_service import StreamingReadFeatureValuesRequest
from .types.featurestore_online_service import StructFieldValue
from .types.featurestore_online_service import StructValue
from .types.featurestore_online_service import WriteFeatureValuesPayload
from .types.featurestore_online_service import WriteFeatureValuesRequest
from .types.featurestore_online_service import WriteFeatureValuesResponse
from .types.featurestore_service import BatchCreateFeaturesOperationMetadata
from .types.featurestore_service import BatchCreateFeaturesRequest
from .types.featurestore_service import BatchCreateFeaturesResponse
from .types.featurestore_service import BatchReadFeatureValuesOperationMetadata
from .types.featurestore_service import BatchReadFeatureValuesRequest
from .types.featurestore_service import BatchReadFeatureValuesResponse
from .types.featurestore_service import CreateEntityTypeOperationMetadata
from .types.featurestore_service import CreateEntityTypeRequest
from .types.featurestore_service import CreateFeatureOperationMetadata
from .types.featurestore_service import CreateFeatureRequest
from .types.featurestore_service import CreateFeaturestoreOperationMetadata
from .types.featurestore_service import CreateFeaturestoreRequest
from .types.featurestore_service import DeleteEntityTypeRequest
from .types.featurestore_service import DeleteFeatureRequest
from .types.featurestore_service import DeleteFeaturestoreRequest
from .types.featurestore_service import DeleteFeatureValuesOperationMetadata
from .types.featurestore_service import DeleteFeatureValuesRequest
from .types.featurestore_service import DeleteFeatureValuesResponse
from .types.featurestore_service import DestinationFeatureSetting
from .types.featurestore_service import EntityIdSelector
from .types.featurestore_service import ExportFeatureValuesOperationMetadata
from .types.featurestore_service import ExportFeatureValuesRequest
from .types.featurestore_service import ExportFeatureValuesResponse
from .types.featurestore_service import FeatureValueDestination
from .types.featurestore_service import GetEntityTypeRequest
from .types.featurestore_service import GetFeatureRequest
from .types.featurestore_service import GetFeaturestoreRequest
from .types.featurestore_service import ImportFeatureValuesOperationMetadata
from .types.featurestore_service import ImportFeatureValuesRequest
from .types.featurestore_service import ImportFeatureValuesResponse
from .types.featurestore_service import ListEntityTypesRequest
from .types.featurestore_service import ListEntityTypesResponse
from .types.featurestore_service import ListFeaturesRequest
from .types.featurestore_service import ListFeaturesResponse
from .types.featurestore_service import ListFeaturestoresRequest
from .types.featurestore_service import ListFeaturestoresResponse
from .types.featurestore_service import SearchFeaturesRequest
from .types.featurestore_service import SearchFeaturesResponse
from .types.featurestore_service import UpdateEntityTypeRequest
from .types.featurestore_service import UpdateFeatureRequest
from .types.featurestore_service import UpdateFeaturestoreOperationMetadata
from .types.featurestore_service import UpdateFeaturestoreRequest
from .types.gen_ai_cache_service import CreateCachedContentRequest
from .types.gen_ai_cache_service import DeleteCachedContentRequest
from .types.gen_ai_cache_service import GetCachedContentRequest
from .types.gen_ai_cache_service import ListCachedContentsRequest
from .types.gen_ai_cache_service import ListCachedContentsResponse
from .types.gen_ai_cache_service import UpdateCachedContentRequest
from .types.genai_tuning_service import CancelTuningJobRequest
from .types.genai_tuning_service import CreateTuningJobRequest
from .types.genai_tuning_service import GetTuningJobRequest
from .types.genai_tuning_service import ListTuningJobsRequest
from .types.genai_tuning_service import ListTuningJobsResponse
from .types.genai_tuning_service import RebaseTunedModelOperationMetadata
from .types.genai_tuning_service import RebaseTunedModelRequest
from .types.hyperparameter_tuning_job import HyperparameterTuningJob
from .types.index import Index
from .types.index import IndexDatapoint
from .types.index import IndexStats
from .types.index_endpoint import DeployedIndex
from .types.index_endpoint import DeployedIndexAuthConfig
from .types.index_endpoint import IndexEndpoint
from .types.index_endpoint import IndexPrivateEndpoints
from .types.index_endpoint_service import CreateIndexEndpointOperationMetadata
from .types.index_endpoint_service import CreateIndexEndpointRequest
from .types.index_endpoint_service import DeleteIndexEndpointRequest
from .types.index_endpoint_service import DeployIndexOperationMetadata
from .types.index_endpoint_service import DeployIndexRequest
from .types.index_endpoint_service import DeployIndexResponse
from .types.index_endpoint_service import GetIndexEndpointRequest
from .types.index_endpoint_service import ListIndexEndpointsRequest
from .types.index_endpoint_service import ListIndexEndpointsResponse
from .types.index_endpoint_service import MutateDeployedIndexOperationMetadata
from .types.index_endpoint_service import MutateDeployedIndexRequest
from .types.index_endpoint_service import MutateDeployedIndexResponse
from .types.index_endpoint_service import UndeployIndexOperationMetadata
from .types.index_endpoint_service import UndeployIndexRequest
from .types.index_endpoint_service import UndeployIndexResponse
from .types.index_endpoint_service import UpdateIndexEndpointRequest
from .types.index_service import CreateIndexOperationMetadata
from .types.index_service import CreateIndexRequest
from .types.index_service import DeleteIndexRequest
from .types.index_service import GetIndexRequest
from .types.index_service import ListIndexesRequest
from .types.index_service import ListIndexesResponse
from .types.index_service import NearestNeighborSearchOperationMetadata
from .types.index_service import RemoveDatapointsRequest
from .types.index_service import RemoveDatapointsResponse
from .types.index_service import UpdateIndexOperationMetadata
from .types.index_service import UpdateIndexRequest
from .types.index_service import UpsertDatapointsRequest
from .types.index_service import UpsertDatapointsResponse
from .types.io import AvroSource
from .types.io import BigQueryDestination
from .types.io import BigQuerySource
from .types.io import ContainerRegistryDestination
from .types.io import CsvDestination
from .types.io import CsvSource
from .types.io import DirectUploadSource
from .types.io import GcsDestination
from .types.io import GcsSource
from .types.io import GoogleDriveSource
from .types.io import JiraSource
from .types.io import SharePointSources
from .types.io import SlackSource
from .types.io import TFRecordDestination
from .types.io import VertexMultimodalDatasetDestination
from .types.io import VertexMultimodalDatasetSource
from .types.job_service import CancelBatchPredictionJobRequest
from .types.job_service import CancelCustomJobRequest
from .types.job_service import CancelDataLabelingJobRequest
from .types.job_service import CancelHyperparameterTuningJobRequest
from .types.job_service import CancelNasJobRequest
from .types.job_service import CreateBatchPredictionJobRequest
from .types.job_service import CreateCustomJobRequest
from .types.job_service import CreateDataLabelingJobRequest
from .types.job_service import CreateHyperparameterTuningJobRequest
from .types.job_service import CreateModelDeploymentMonitoringJobRequest
from .types.job_service import CreateNasJobRequest
from .types.job_service import DeleteBatchPredictionJobRequest
from .types.job_service import DeleteCustomJobRequest
from .types.job_service import DeleteDataLabelingJobRequest
from .types.job_service import DeleteHyperparameterTuningJobRequest
from .types.job_service import DeleteModelDeploymentMonitoringJobRequest
from .types.job_service import DeleteNasJobRequest
from .types.job_service import GetBatchPredictionJobRequest
from .types.job_service import GetCustomJobRequest
from .types.job_service import GetDataLabelingJobRequest
from .types.job_service import GetHyperparameterTuningJobRequest
from .types.job_service import GetModelDeploymentMonitoringJobRequest
from .types.job_service import GetNasJobRequest
from .types.job_service import GetNasTrialDetailRequest
from .types.job_service import ListBatchPredictionJobsRequest
from .types.job_service import ListBatchPredictionJobsResponse
from .types.job_service import ListCustomJobsRequest
from .types.job_service import ListCustomJobsResponse
from .types.job_service import ListDataLabelingJobsRequest
from .types.job_service import ListDataLabelingJobsResponse
from .types.job_service import ListHyperparameterTuningJobsRequest
from .types.job_service import ListHyperparameterTuningJobsResponse
from .types.job_service import ListModelDeploymentMonitoringJobsRequest
from .types.job_service import ListModelDeploymentMonitoringJobsResponse
from .types.job_service import ListNasJobsRequest
from .types.job_service import ListNasJobsResponse
from .types.job_service import ListNasTrialDetailsRequest
from .types.job_service import ListNasTrialDetailsResponse
from .types.job_service import PauseModelDeploymentMonitoringJobRequest
from .types.job_service import ResumeModelDeploymentMonitoringJobRequest
from .types.job_service import SearchModelDeploymentMonitoringStatsAnomaliesRequest
from .types.job_service import SearchModelDeploymentMonitoringStatsAnomaliesResponse
from .types.job_service import UpdateModelDeploymentMonitoringJobOperationMetadata
from .types.job_service import UpdateModelDeploymentMonitoringJobRequest
from .types.job_state import JobState
from .types.lineage_subgraph import LineageSubgraph
from .types.llm_utility_service import ComputeTokensRequest
from .types.llm_utility_service import ComputeTokensResponse
from .types.llm_utility_service import TokensInfo
from .types.machine_resources import AutomaticResources
from .types.machine_resources import AutoscalingMetricSpec
from .types.machine_resources import BatchDedicatedResources
from .types.machine_resources import DedicatedResources
from .types.machine_resources import DiskSpec
from .types.machine_resources import LustreMount
from .types.machine_resources import MachineSpec
from .types.machine_resources import NfsMount
from .types.machine_resources import PersistentDiskSpec
from .types.machine_resources import ResourcesConsumed
from .types.machine_resources import ShieldedVmConfig
from .types.manual_batch_tuning_parameters import ManualBatchTuningParameters
from .types.match_service import FindNeighborsRequest
from .types.match_service import FindNeighborsResponse
from .types.match_service import ReadIndexDatapointsRequest
from .types.match_service import ReadIndexDatapointsResponse
from .types.metadata_schema import MetadataSchema
from .types.metadata_service import AddContextArtifactsAndExecutionsRequest
from .types.metadata_service import AddContextArtifactsAndExecutionsResponse
from .types.metadata_service import AddContextChildrenRequest
from .types.metadata_service import AddContextChildrenResponse
from .types.metadata_service import AddExecutionEventsRequest
from .types.metadata_service import AddExecutionEventsResponse
from .types.metadata_service import CreateArtifactRequest
from .types.metadata_service import CreateContextRequest
from .types.metadata_service import CreateExecutionRequest
from .types.metadata_service import CreateMetadataSchemaRequest
from .types.metadata_service import CreateMetadataStoreOperationMetadata
from .types.metadata_service import CreateMetadataStoreRequest
from .types.metadata_service import DeleteArtifactRequest
from .types.metadata_service import DeleteContextRequest
from .types.metadata_service import DeleteExecutionRequest
from .types.metadata_service import DeleteMetadataStoreOperationMetadata
from .types.metadata_service import DeleteMetadataStoreRequest
from .types.metadata_service import GetArtifactRequest
from .types.metadata_service import GetContextRequest
from .types.metadata_service import GetExecutionRequest
from .types.metadata_service import GetMetadataSchemaRequest
from .types.metadata_service import GetMetadataStoreRequest
from .types.metadata_service import ListArtifactsRequest
from .types.metadata_service import ListArtifactsResponse
from .types.metadata_service import ListContextsRequest
from .types.metadata_service import ListContextsResponse
from .types.metadata_service import ListExecutionsRequest
from .types.metadata_service import ListExecutionsResponse
from .types.metadata_service import ListMetadataSchemasRequest
from .types.metadata_service import ListMetadataSchemasResponse
from .types.metadata_service import ListMetadataStoresRequest
from .types.metadata_service import ListMetadataStoresResponse
from .types.metadata_service import PurgeArtifactsMetadata
from .types.metadata_service import PurgeArtifactsRequest
from .types.metadata_service import PurgeArtifactsResponse
from .types.metadata_service import PurgeContextsMetadata
from .types.metadata_service import PurgeContextsRequest
from .types.metadata_service import PurgeContextsResponse
from .types.metadata_service import PurgeExecutionsMetadata
from .types.metadata_service import PurgeExecutionsRequest
from .types.metadata_service import PurgeExecutionsResponse
from .types.metadata_service import QueryArtifactLineageSubgraphRequest
from .types.metadata_service import QueryContextLineageSubgraphRequest
from .types.metadata_service import QueryExecutionInputsAndOutputsRequest
from .types.metadata_service import RemoveContextChildrenRequest
from .types.metadata_service import RemoveContextChildrenResponse
from .types.metadata_service import UpdateArtifactRequest
from .types.metadata_service import UpdateContextRequest
from .types.metadata_service import UpdateExecutionRequest
from .types.metadata_store import MetadataStore
from .types.migratable_resource import MigratableResource
from .types.migration_service import BatchMigrateResourcesOperationMetadata
from .types.migration_service import BatchMigrateResourcesRequest
from .types.migration_service import BatchMigrateResourcesResponse
from .types.migration_service import MigrateResourceRequest
from .types.migration_service import MigrateResourceResponse
from .types.migration_service import SearchMigratableResourcesRequest
from .types.migration_service import SearchMigratableResourcesResponse
from .types.model import Checkpoint
from .types.model import GenieSource
from .types.model import LargeModelReference
from .types.model import Model
from .types.model import ModelContainerSpec
from .types.model import ModelGardenSource
from .types.model import ModelSourceInfo
from .types.model import Port
from .types.model import PredictSchemata
from .types.model import Probe
from .types.model_deployment_monitoring_job import (
    ModelDeploymentMonitoringBigQueryTable,
)
from .types.model_deployment_monitoring_job import ModelDeploymentMonitoringJob
from .types.model_deployment_monitoring_job import (
    ModelDeploymentMonitoringObjectiveConfig,
)
from .types.model_deployment_monitoring_job import (
    ModelDeploymentMonitoringScheduleConfig,
)
from .types.model_deployment_monitoring_job import ModelMonitoringStatsAnomalies
from .types.model_deployment_monitoring_job import (
    ModelDeploymentMonitoringObjectiveType,
)
from .types.model_evaluation import ModelEvaluation
from .types.model_evaluation_slice import ModelEvaluationSlice
from .types.model_garden_service import DeployOperationMetadata
from .types.model_garden_service import DeployRequest
from .types.model_garden_service import DeployResponse
from .types.model_garden_service import GetPublisherModelRequest
from .types.model_garden_service import PublisherModelView
from .types.model_monitoring import ModelMonitoringAlertConfig
from .types.model_monitoring import ModelMonitoringObjectiveConfig
from .types.model_monitoring import SamplingStrategy
from .types.model_monitoring import ThresholdConfig
from .types.model_service import BatchImportEvaluatedAnnotationsRequest
from .types.model_service import BatchImportEvaluatedAnnotationsResponse
from .types.model_service import BatchImportModelEvaluationSlicesRequest
from .types.model_service import BatchImportModelEvaluationSlicesResponse
from .types.model_service import CopyModelOperationMetadata
from .types.model_service import CopyModelRequest
from .types.model_service import CopyModelResponse
from .types.model_service import DeleteModelRequest
from .types.model_service import DeleteModelVersionRequest
from .types.model_service import ExportModelOperationMetadata
from .types.model_service import ExportModelRequest
from .types.model_service import ExportModelResponse
from .types.model_service import GetModelEvaluationRequest
from .types.model_service import GetModelEvaluationSliceRequest
from .types.model_service import GetModelRequest
from .types.model_service import ImportModelEvaluationRequest
from .types.model_service import ListModelEvaluationSlicesRequest
from .types.model_service import ListModelEvaluationSlicesResponse
from .types.model_service import ListModelEvaluationsRequest
from .types.model_service import ListModelEvaluationsResponse
from .types.model_service import ListModelsRequest
from .types.model_service import ListModelsResponse
from .types.model_service import ListModelVersionCheckpointsRequest
from .types.model_service import ListModelVersionCheckpointsResponse
from .types.model_service import ListModelVersionsRequest
from .types.model_service import ListModelVersionsResponse
from .types.model_service import MergeVersionAliasesRequest
from .types.model_service import ModelVersionCheckpoint
from .types.model_service import UpdateExplanationDatasetOperationMetadata
from .types.model_service import UpdateExplanationDatasetRequest
from .types.model_service import UpdateExplanationDatasetResponse
from .types.model_service import UpdateModelRequest
from .types.model_service import UploadModelOperationMetadata
from .types.model_service import UploadModelRequest
from .types.model_service import UploadModelResponse
from .types.nas_job import NasJob
from .types.nas_job import NasJobOutput
from .types.nas_job import NasJobSpec
from .types.nas_job import NasTrial
from .types.nas_job import NasTrialDetail
from .types.network_spec import NetworkSpec
from .types.notebook_euc_config import NotebookEucConfig
from .types.notebook_execution_job import NotebookExecutionJob
from .types.notebook_idle_shutdown_config import NotebookIdleShutdownConfig
from .types.notebook_runtime import NotebookRuntime
from .types.notebook_runtime import NotebookRuntimeTemplate
from .types.notebook_runtime import NotebookRuntimeType
from .types.notebook_runtime_template_ref import NotebookRuntimeTemplateRef
from .types.notebook_service import AssignNotebookRuntimeOperationMetadata
from .types.notebook_service import AssignNotebookRuntimeRequest
from .types.notebook_service import CreateNotebookExecutionJobOperationMetadata
from .types.notebook_service import CreateNotebookExecutionJobRequest
from .types.notebook_service import CreateNotebookRuntimeTemplateOperationMetadata
from .types.notebook_service import CreateNotebookRuntimeTemplateRequest
from .types.notebook_service import DeleteNotebookExecutionJobRequest
from .types.notebook_service import DeleteNotebookRuntimeRequest
from .types.notebook_service import DeleteNotebookRuntimeTemplateRequest
from .types.notebook_service import GetNotebookExecutionJobRequest
from .types.notebook_service import GetNotebookRuntimeRequest
from .types.notebook_service import GetNotebookRuntimeTemplateRequest
from .types.notebook_service import ListNotebookExecutionJobsRequest
from .types.notebook_service import ListNotebookExecutionJobsResponse
from .types.notebook_service import ListNotebookRuntimesRequest
from .types.notebook_service import ListNotebookRuntimesResponse
from .types.notebook_service import ListNotebookRuntimeTemplatesRequest
from .types.notebook_service import ListNotebookRuntimeTemplatesResponse
from .types.notebook_service import StartNotebookRuntimeOperationMetadata
from .types.notebook_service import StartNotebookRuntimeRequest
from .types.notebook_service import StartNotebookRuntimeResponse
from .types.notebook_service import StopNotebookRuntimeOperationMetadata
from .types.notebook_service import StopNotebookRuntimeRequest
from .types.notebook_service import StopNotebookRuntimeResponse
from .types.notebook_service import UpdateNotebookRuntimeTemplateRequest
from .types.notebook_service import UpgradeNotebookRuntimeOperationMetadata
from .types.notebook_service import UpgradeNotebookRuntimeRequest
from .types.notebook_service import UpgradeNotebookRuntimeResponse
from .types.notebook_service import NotebookExecutionJobView
from .types.notebook_software_config import ColabImage
from .types.notebook_software_config import NotebookSoftwareConfig
from .types.notebook_software_config import PostStartupScriptConfig
from .types.openapi import Schema
from .types.openapi import Type
from .types.operation import DeleteOperationMetadata
from .types.operation import GenericOperationMetadata
from .types.persistent_resource import PersistentResource
from .types.persistent_resource import RayLogsSpec
from .types.persistent_resource import RayMetricSpec
from .types.persistent_resource import RaySpec
from .types.persistent_resource import ResourcePool
from .types.persistent_resource import ResourceRuntime
from .types.persistent_resource import ResourceRuntimeSpec
from .types.persistent_resource import ServiceAccountSpec
from .types.persistent_resource_service import CreatePersistentResourceOperationMetadata
from .types.persistent_resource_service import CreatePersistentResourceRequest
from .types.persistent_resource_service import DeletePersistentResourceRequest
from .types.persistent_resource_service import GetPersistentResourceRequest
from .types.persistent_resource_service import ListPersistentResourcesRequest
from .types.persistent_resource_service import ListPersistentResourcesResponse
from .types.persistent_resource_service import RebootPersistentResourceOperationMetadata
from .types.persistent_resource_service import RebootPersistentResourceRequest
from .types.persistent_resource_service import UpdatePersistentResourceOperationMetadata
from .types.persistent_resource_service import UpdatePersistentResourceRequest
from .types.pipeline_failure_policy import PipelineFailurePolicy
from .types.pipeline_job import PipelineJob
from .types.pipeline_job import PipelineJobDetail
from .types.pipeline_job import PipelineTaskDetail
from .types.pipeline_job import PipelineTaskExecutorDetail
from .types.pipeline_job import PipelineTemplateMetadata
from .types.pipeline_service import BatchCancelPipelineJobsOperationMetadata
from .types.pipeline_service import BatchCancelPipelineJobsRequest
from .types.pipeline_service import BatchCancelPipelineJobsResponse
from .types.pipeline_service import BatchDeletePipelineJobsRequest
from .types.pipeline_service import BatchDeletePipelineJobsResponse
from .types.pipeline_service import CancelPipelineJobRequest
from .types.pipeline_service import CancelTrainingPipelineRequest
from .types.pipeline_service import CreatePipelineJobRequest
from .types.pipeline_service import CreateTrainingPipelineRequest
from .types.pipeline_service import DeletePipelineJobRequest
from .types.pipeline_service import DeleteTrainingPipelineRequest
from .types.pipeline_service import GetPipelineJobRequest
from .types.pipeline_service import GetTrainingPipelineRequest
from .types.pipeline_service import ListPipelineJobsRequest
from .types.pipeline_service import ListPipelineJobsResponse
from .types.pipeline_service import ListTrainingPipelinesRequest
from .types.pipeline_service import ListTrainingPipelinesResponse
from .types.pipeline_state import PipelineState
from .types.prediction_service import CountTokensRequest
from .types.prediction_service import CountTokensResponse
from .types.prediction_service import DirectPredictRequest
from .types.prediction_service import DirectPredictResponse
from .types.prediction_service import DirectRawPredictRequest
from .types.prediction_service import DirectRawPredictResponse
from .types.prediction_service import EmbedContentRequest
from .types.prediction_service import EmbedContentResponse
from .types.prediction_service import ExplainRequest
from .types.prediction_service import ExplainResponse
from .types.prediction_service import GenerateContentRequest
from .types.prediction_service import GenerateContentResponse
from .types.prediction_service import PredictRequest
from .types.prediction_service import PredictResponse
from .types.prediction_service import RawPredictRequest
from .types.prediction_service import StreamDirectPredictRequest
from .types.prediction_service import StreamDirectPredictResponse
from .types.prediction_service import StreamDirectRawPredictRequest
from .types.prediction_service import StreamDirectRawPredictResponse
from .types.prediction_service import StreamingPredictRequest
from .types.prediction_service import StreamingPredictResponse
from .types.prediction_service import StreamingRawPredictRequest
from .types.prediction_service import StreamingRawPredictResponse
from .types.prediction_service import StreamRawPredictRequest
from .types.publisher_model import PublisherModel
from .types.reasoning_engine import ReasoningEngine
from .types.reasoning_engine import ReasoningEngineSpec
from .types.reasoning_engine_execution_service import (
    AsyncQueryReasoningEngineOperationMetadata,
)
from .types.reasoning_engine_execution_service import AsyncQueryReasoningEngineRequest
from .types.reasoning_engine_execution_service import AsyncQueryReasoningEngineResponse
from .types.reasoning_engine_execution_service import (
    CancelAsyncQueryReasoningEngineRequest,
)
from .types.reasoning_engine_execution_service import (
    CancelAsyncQueryReasoningEngineResponse,
)
from .types.reasoning_engine_execution_service import QueryReasoningEngineRequest
from .types.reasoning_engine_execution_service import QueryReasoningEngineResponse
from .types.reasoning_engine_execution_service import StreamQueryReasoningEngineRequest
from .types.reasoning_engine_service import CreateReasoningEngineOperationMetadata
from .types.reasoning_engine_service import CreateReasoningEngineRequest
from .types.reasoning_engine_service import DeleteReasoningEngineRequest
from .types.reasoning_engine_service import GetReasoningEngineRequest
from .types.reasoning_engine_service import ListReasoningEnginesRequest
from .types.reasoning_engine_service import ListReasoningEnginesResponse
from .types.reasoning_engine_service import UpdateReasoningEngineOperationMetadata
from .types.reasoning_engine_service import UpdateReasoningEngineRequest
from .types.reservation_affinity import ReservationAffinity
from .types.saved_query import SavedQuery
from .types.schedule import Schedule
from .types.schedule_service import CreateScheduleRequest
from .types.schedule_service import DeleteScheduleRequest
from .types.schedule_service import GetScheduleRequest
from .types.schedule_service import ListSchedulesRequest
from .types.schedule_service import ListSchedulesResponse
from .types.schedule_service import PauseScheduleRequest
from .types.schedule_service import ResumeScheduleRequest
from .types.schedule_service import UpdateScheduleRequest
from .types.service_networking import DnsPeeringConfig
from .types.service_networking import PrivateServiceConnectConfig
from .types.service_networking import PscAutomatedEndpoints
from .types.service_networking import PSCAutomationConfig
from .types.service_networking import PscInterfaceConfig
from .types.service_networking import PSCAutomationState
from .types.session import EventActions
from .types.session import EventMetadata
from .types.session import Session
from .types.session import SessionEvent
from .types.session import Transcription
from .types.session_service import AppendEventRequest
from .types.session_service import AppendEventResponse
from .types.session_service import CreateSessionOperationMetadata
from .types.session_service import CreateSessionRequest
from .types.session_service import DeleteSessionRequest
from .types.session_service import GetSessionRequest
from .types.session_service import ListEventsRequest
from .types.session_service import ListEventsResponse
from .types.session_service import ListSessionsRequest
from .types.session_service import ListSessionsResponse
from .types.session_service import UpdateSessionRequest
from .types.specialist_pool import SpecialistPool
from .types.specialist_pool_service import CreateSpecialistPoolOperationMetadata
from .types.specialist_pool_service import CreateSpecialistPoolRequest
from .types.specialist_pool_service import DeleteSpecialistPoolRequest
from .types.specialist_pool_service import GetSpecialistPoolRequest
from .types.specialist_pool_service import ListSpecialistPoolsRequest
from .types.specialist_pool_service import ListSpecialistPoolsResponse
from .types.specialist_pool_service import UpdateSpecialistPoolOperationMetadata
from .types.specialist_pool_service import UpdateSpecialistPoolRequest
from .types.study import Measurement
from .types.study import Study
from .types.study import StudySpec
from .types.study import StudyTimeConstraint
from .types.study import Trial
from .types.study import TrialContext
from .types.tensorboard import Tensorboard
from .types.tensorboard_data import Scalar
from .types.tensorboard_data import TensorboardBlob
from .types.tensorboard_data import TensorboardBlobSequence
from .types.tensorboard_data import TensorboardTensor
from .types.tensorboard_data import TimeSeriesData
from .types.tensorboard_data import TimeSeriesDataPoint
from .types.tensorboard_experiment import TensorboardExperiment
from .types.tensorboard_run import TensorboardRun
from .types.tensorboard_service import BatchCreateTensorboardRunsRequest
from .types.tensorboard_service import BatchCreateTensorboardRunsResponse
from .types.tensorboard_service import BatchCreateTensorboardTimeSeriesRequest
from .types.tensorboard_service import BatchCreateTensorboardTimeSeriesResponse
from .types.tensorboard_service import BatchReadTensorboardTimeSeriesDataRequest
from .types.tensorboard_service import BatchReadTensorboardTimeSeriesDataResponse
from .types.tensorboard_service import CreateTensorboardExperimentRequest
from .types.tensorboard_service import CreateTensorboardOperationMetadata
from .types.tensorboard_service import CreateTensorboardRequest
from .types.tensorboard_service import CreateTensorboardRunRequest
from .types.tensorboard_service import CreateTensorboardTimeSeriesRequest
from .types.tensorboard_service import DeleteTensorboardExperimentRequest
from .types.tensorboard_service import DeleteTensorboardRequest
from .types.tensorboard_service import DeleteTensorboardRunRequest
from .types.tensorboard_service import DeleteTensorboardTimeSeriesRequest
from .types.tensorboard_service import ExportTensorboardTimeSeriesDataRequest
from .types.tensorboard_service import ExportTensorboardTimeSeriesDataResponse
from .types.tensorboard_service import GetTensorboardExperimentRequest
from .types.tensorboard_service import GetTensorboardRequest
from .types.tensorboard_service import GetTensorboardRunRequest
from .types.tensorboard_service import GetTensorboardTimeSeriesRequest
from .types.tensorboard_service import ListTensorboardExperimentsRequest
from .types.tensorboard_service import ListTensorboardExperimentsResponse
from .types.tensorboard_service import ListTensorboardRunsRequest
from .types.tensorboard_service import ListTensorboardRunsResponse
from .types.tensorboard_service import ListTensorboardsRequest
from .types.tensorboard_service import ListTensorboardsResponse
from .types.tensorboard_service import ListTensorboardTimeSeriesRequest
from .types.tensorboard_service import ListTensorboardTimeSeriesResponse
from .types.tensorboard_service import ReadTensorboardBlobDataRequest
from .types.tensorboard_service import ReadTensorboardBlobDataResponse
from .types.tensorboard_service import ReadTensorboardSizeRequest
from .types.tensorboard_service import ReadTensorboardSizeResponse
from .types.tensorboard_service import ReadTensorboardTimeSeriesDataRequest
from .types.tensorboard_service import ReadTensorboardTimeSeriesDataResponse
from .types.tensorboard_service import ReadTensorboardUsageRequest
from .types.tensorboard_service import ReadTensorboardUsageResponse
from .types.tensorboard_service import UpdateTensorboardExperimentRequest
from .types.tensorboard_service import UpdateTensorboardOperationMetadata
from .types.tensorboard_service import UpdateTensorboardRequest
from .types.tensorboard_service import UpdateTensorboardRunRequest
from .types.tensorboard_service import UpdateTensorboardTimeSeriesRequest
from .types.tensorboard_service import WriteTensorboardExperimentDataRequest
from .types.tensorboard_service import WriteTensorboardExperimentDataResponse
from .types.tensorboard_service import WriteTensorboardRunDataRequest
from .types.tensorboard_service import WriteTensorboardRunDataResponse
from .types.tensorboard_time_series import TensorboardTimeSeries
from .types.tool import CodeExecutionResult
from .types.tool import DynamicRetrievalConfig
from .types.tool import EnterpriseWebSearch
from .types.tool import ExecutableCode
from .types.tool import FunctionCall
from .types.tool import FunctionCallingConfig
from .types.tool import FunctionDeclaration
from .types.tool import FunctionResponse
from .types.tool import FunctionResponseBlob
from .types.tool import FunctionResponseFileData
from .types.tool import FunctionResponsePart
from .types.tool import GoogleMaps
from .types.tool import GoogleSearchRetrieval
from .types.tool import PartialArg
from .types.tool import RagRetrievalConfig
from .types.tool import Retrieval
from .types.tool import RetrievalConfig
from .types.tool import Tool
from .types.tool import ToolConfig
from .types.tool import UrlContext
from .types.tool import VertexAISearch
from .types.tool import VertexRagStore
from .types.training_pipeline import FilterSplit
from .types.training_pipeline import FractionSplit
from .types.training_pipeline import InputDataConfig
from .types.training_pipeline import PredefinedSplit
from .types.training_pipeline import StratifiedSplit
from .types.training_pipeline import TimestampSplit
from .types.training_pipeline import TrainingPipeline
from .types.tuning_job import EvaluateDatasetRun
from .types.tuning_job import EvaluationConfig
from .types.tuning_job import PreTunedModel
from .types.tuning_job import SupervisedHyperParameters
from .types.tuning_job import SupervisedTuningDatasetDistribution
from .types.tuning_job import SupervisedTuningDataStats
from .types.tuning_job import SupervisedTuningSpec
from .types.tuning_job import TunedModel
from .types.tuning_job import TunedModelCheckpoint
from .types.tuning_job import TunedModelRef
from .types.tuning_job import TuningDataStats
from .types.tuning_job import TuningJob
from .types.types import BoolArray
from .types.types import DoubleArray
from .types.types import Int64Array
from .types.types import StringArray
from .types.types import Tensor
from .types.unmanaged_container_model import UnmanagedContainerModel
from .types.usage_metadata import UsageMetadata
from .types.user_action_reference import UserActionReference
from .types.value import Value
from .types.vertex_rag_data import CorpusStatus
from .types.vertex_rag_data import FileStatus
from .types.vertex_rag_data import ImportRagFilesConfig
from .types.vertex_rag_data import RagChunk
from .types.vertex_rag_data import RagCorpus
from .types.vertex_rag_data import RagEmbeddingModelConfig
from .types.vertex_rag_data import RagEngineConfig
from .types.vertex_rag_data import RagFile
from .types.vertex_rag_data import RagFileChunkingConfig
from .types.vertex_rag_data import RagFileParsingConfig
from .types.vertex_rag_data import RagFileTransformationConfig
from .types.vertex_rag_data import RagManagedDbConfig
from .types.vertex_rag_data import RagVectorDbConfig
from .types.vertex_rag_data import UploadRagFileConfig
from .types.vertex_rag_data import VertexAiSearchConfig
from .types.vertex_rag_data_service import CreateRagCorpusOperationMetadata
from .types.vertex_rag_data_service import CreateRagCorpusRequest
from .types.vertex_rag_data_service import DeleteRagCorpusRequest
from .types.vertex_rag_data_service import DeleteRagFileRequest
from .types.vertex_rag_data_service import GetRagCorpusRequest
from .types.vertex_rag_data_service import GetRagEngineConfigRequest
from .types.vertex_rag_data_service import GetRagFileRequest
from .types.vertex_rag_data_service import ImportRagFilesOperationMetadata
from .types.vertex_rag_data_service import ImportRagFilesRequest
from .types.vertex_rag_data_service import ImportRagFilesResponse
from .types.vertex_rag_data_service import ListRagCorporaRequest
from .types.vertex_rag_data_service import ListRagCorporaResponse
from .types.vertex_rag_data_service import ListRagFilesRequest
from .types.vertex_rag_data_service import ListRagFilesResponse
from .types.vertex_rag_data_service import UpdateRagCorpusOperationMetadata
from .types.vertex_rag_data_service import UpdateRagCorpusRequest
from .types.vertex_rag_data_service import UpdateRagEngineConfigOperationMetadata
from .types.vertex_rag_data_service import UpdateRagEngineConfigRequest
from .types.vertex_rag_data_service import UploadRagFileRequest
from .types.vertex_rag_data_service import UploadRagFileResponse
from .types.vertex_rag_service import AskContextsRequest
from .types.vertex_rag_service import AskContextsResponse
from .types.vertex_rag_service import AsyncRetrieveContextsOperationMetadata
from .types.vertex_rag_service import AsyncRetrieveContextsRequest
from .types.vertex_rag_service import AsyncRetrieveContextsResponse
from .types.vertex_rag_service import AugmentPromptRequest
from .types.vertex_rag_service import AugmentPromptResponse
from .types.vertex_rag_service import Claim
from .types.vertex_rag_service import CorroborateContentRequest
from .types.vertex_rag_service import CorroborateContentResponse
from .types.vertex_rag_service import Fact
from .types.vertex_rag_service import RagContexts
from .types.vertex_rag_service import RagQuery
from .types.vertex_rag_service import RetrieveContextsRequest
from .types.vertex_rag_service import RetrieveContextsResponse
from .types.vizier_service import AddTrialMeasurementRequest
from .types.vizier_service import CheckTrialEarlyStoppingStateMetatdata
from .types.vizier_service import CheckTrialEarlyStoppingStateRequest
from .types.vizier_service import CheckTrialEarlyStoppingStateResponse
from .types.vizier_service import CompleteTrialRequest
from .types.vizier_service import CreateStudyRequest
from .types.vizier_service import CreateTrialRequest
from .types.vizier_service import DeleteStudyRequest
from .types.vizier_service import DeleteTrialRequest
from .types.vizier_service import GetStudyRequest
from .types.vizier_service import GetTrialRequest
from .types.vizier_service import ListOptimalTrialsRequest
from .types.vizier_service import ListOptimalTrialsResponse
from .types.vizier_service import ListStudiesRequest
from .types.vizier_service import ListStudiesResponse
from .types.vizier_service import ListTrialsRequest
from .types.vizier_service import ListTrialsResponse
from .types.vizier_service import LookupStudyRequest
from .types.vizier_service import StopTrialRequest
from .types.vizier_service import SuggestTrialsMetadata
from .types.vizier_service import SuggestTrialsRequest
from .types.vizier_service import SuggestTrialsResponse

if hasattr(api_core, "check_python_version") and hasattr(
    api_core, "check_dependency_versions"
):  # pragma: NO COVER
    api_core.check_python_version("google.cloud.aiplatform_v1")  # type: ignore
    api_core.check_dependency_versions("google.cloud.aiplatform_v1")  # type: ignore
else:  # pragma: NO COVER
    # An older version of api_core is installed which does not define the
    # functions above. We do equivalent checks manually.
    try:
        import warnings

        _py_version_str = sys.version.split()[0]
        _package_label = "google.cloud.aiplatform_v1"
        if sys.version_info < (3, 10):
            warnings.warn(
                "You are using a non-supported Python version "
                + f"({_py_version_str}).  Google will not post any further "
                + f"updates to {_package_label} supporting this Python version. "
                + "Please upgrade to the latest Python version, or at "
                + f"least to Python 3.10, and then update {_package_label}.",
                FutureWarning,
            )

        def parse_version_to_tuple(version_string: str):
            """Safely converts a semantic version string to a comparable tuple of integers.
            Example: "6.33.5" -> (6, 33, 5)
            Ignores non-numeric parts and handles common version formats.
            Args:
                version_string: Version string in the format "x.y.z" or "x.y.z<suffix>"
            Returns:
                Tuple of integers for the parsed version string.
            """
            parts = []
            for part in version_string.split("."):
                try:
                    parts.append(int(part))
                except ValueError:
                    # If it's a non-numeric part (e.g., '1.0.0b1' -> 'b1'), stop here.
                    # This is a simplification compared to 'packaging.parse_version', but sufficient
                    # for comparing strictly numeric semantic versions.
                    break
            return tuple(parts)

        def _get_version(dependency_name):
            try:
                version_string: str = metadata.version(dependency_name)
                parsed_version = parse_version_to_tuple(version_string)
                return (parsed_version, version_string)
            except Exception:
                # Catch exceptions from metadata.version() (e.g., PackageNotFoundError)
                # or errors during parse_version_to_tuple
                return (None, "--")

        _dependency_package = "google.protobuf"
        _next_supported_version = "6.33.5"
        _next_supported_version_tuple = (6, 33, 5)
        _recommendation = " (we recommend 7.x)"
        (_version_used, _version_used_string) = _get_version(_dependency_package)
        if _version_used and _version_used < _next_supported_version_tuple:
            warnings.warn(
                f"Package {_package_label} depends on "
                + f"{_dependency_package}, currently installed at version "
                + f"{_version_used_string}. Future updates to "
                + f"{_package_label} will require {_dependency_package} at "
                + f"version {_next_supported_version} or higher{_recommendation}."
                + " Please ensure "
                + "that either (a) your Python environment doesn't pin the "
                + f"version of {_dependency_package}, so that updates to "
                + f"{_package_label} can require the higher version, or "
                + "(b) you manually update your Python environment to use at "
                + f"least version {_next_supported_version} of "
                + f"{_dependency_package}.",
                FutureWarning,
            )
    except Exception:
        warnings.warn(
            "Could not determine the version of Python "
            + "currently being used. To continue receiving "
            + "updates for {_package_label}, ensure you are "
            + "using a supported version of Python; see "
            + "https://devguide.python.org/versions/"
        )

__all__ = (
    "DataFoundryServiceAsyncClient",
    "DatasetServiceAsyncClient",
    "DeploymentResourcePoolServiceAsyncClient",
    "EndpointServiceAsyncClient",
    "EvaluationServiceAsyncClient",
    "FeatureOnlineStoreAdminServiceAsyncClient",
    "FeatureOnlineStoreServiceAsyncClient",
    "FeatureRegistryServiceAsyncClient",
    "FeaturestoreOnlineServingServiceAsyncClient",
    "FeaturestoreServiceAsyncClient",
    "GenAiCacheServiceAsyncClient",
    "GenAiTuningServiceAsyncClient",
    "IndexEndpointServiceAsyncClient",
    "IndexServiceAsyncClient",
    "JobServiceAsyncClient",
    "LlmUtilityServiceAsyncClient",
    "MatchServiceAsyncClient",
    "MetadataServiceAsyncClient",
    "MigrationServiceAsyncClient",
    "ModelGardenServiceAsyncClient",
    "ModelServiceAsyncClient",
    "NotebookServiceAsyncClient",
    "PersistentResourceServiceAsyncClient",
    "PipelineServiceAsyncClient",
    "PredictionServiceAsyncClient",
    "ReasoningEngineExecutionServiceAsyncClient",
    "ReasoningEngineServiceAsyncClient",
    "ScheduleServiceAsyncClient",
    "SessionServiceAsyncClient",
    "SpecialistPoolServiceAsyncClient",
    "TensorboardServiceAsyncClient",
    "VertexRagDataServiceAsyncClient",
    "VertexRagServiceAsyncClient",
    "VizierServiceAsyncClient",
    "AcceleratorType",
    "ActiveLearningConfig",
    "AddContextArtifactsAndExecutionsRequest",
    "AddContextArtifactsAndExecutionsResponse",
    "AddContextChildrenRequest",
    "AddContextChildrenResponse",
    "AddExecutionEventsRequest",
    "AddExecutionEventsResponse",
    "AddTrialMeasurementRequest",
    "AggregationOutput",
    "AggregationResult",
    "Annotation",
    "AnnotationSpec",
    "ApiAuth",
    "AppendEventRequest",
    "AppendEventResponse",
    "Artifact",
    "AskContextsRequest",
    "AskContextsResponse",
    "AssignNotebookRuntimeOperationMetadata",
    "AssignNotebookRuntimeRequest",
    "AsyncQueryReasoningEngineOperationMetadata",
    "AsyncQueryReasoningEngineRequest",
    "AsyncQueryReasoningEngineResponse",
    "AsyncRetrieveContextsOperationMetadata",
    "AsyncRetrieveContextsRequest",
    "AsyncRetrieveContextsResponse",
    "Attribution",
    "AugmentPromptRequest",
    "AugmentPromptResponse",
    "AutomaticResources",
    "AutoraterConfig",
    "AutoscalingMetricSpec",
    "AvroSource",
    "BatchCancelPipelineJobsOperationMetadata",
    "BatchCancelPipelineJobsRequest",
    "BatchCancelPipelineJobsResponse",
    "BatchCreateFeaturesOperationMetadata",
    "BatchCreateFeaturesRequest",
    "BatchCreateFeaturesResponse",
    "BatchCreateTensorboardRunsRequest",
    "BatchCreateTensorboardRunsResponse",
    "BatchCreateTensorboardTimeSeriesRequest",
    "BatchCreateTensorboardTimeSeriesResponse",
    "BatchDedicatedResources",
    "BatchDeletePipelineJobsRequest",
    "BatchDeletePipelineJobsResponse",
    "BatchImportEvaluatedAnnotationsRequest",
    "BatchImportEvaluatedAnnotationsResponse",
    "BatchImportModelEvaluationSlicesRequest",
    "BatchImportModelEvaluationSlicesResponse",
    "BatchMigrateResourcesOperationMetadata",
    "BatchMigrateResourcesRequest",
    "BatchMigrateResourcesResponse",
    "BatchPredictionJob",
    "BatchReadFeatureValuesOperationMetadata",
    "BatchReadFeatureValuesRequest",
    "BatchReadFeatureValuesResponse",
    "BatchReadTensorboardTimeSeriesDataRequest",
    "BatchReadTensorboardTimeSeriesDataResponse",
    "BigQueryDestination",
    "BigQuerySource",
    "BleuInput",
    "BleuInstance",
    "BleuMetricValue",
    "BleuResults",
    "BleuSpec",
    "Blob",
    "BlurBaselineConfig",
    "BoolArray",
    "CachedContent",
    "CancelAsyncQueryReasoningEngineRequest",
    "CancelAsyncQueryReasoningEngineResponse",
    "CancelBatchPredictionJobRequest",
    "CancelCustomJobRequest",
    "CancelDataLabelingJobRequest",
    "CancelHyperparameterTuningJobRequest",
    "CancelNasJobRequest",
    "CancelPipelineJobRequest",
    "CancelTrainingPipelineRequest",
    "CancelTuningJobRequest",
    "Candidate",
    "CheckTrialEarlyStoppingStateMetatdata",
    "CheckTrialEarlyStoppingStateRequest",
    "CheckTrialEarlyStoppingStateResponse",
    "Checkpoint",
    "Citation",
    "CitationMetadata",
    "Claim",
    "ClientConnectionConfig",
    "CodeExecutionResult",
    "CoherenceInput",
    "CoherenceInstance",
    "CoherenceResult",
    "CoherenceSpec",
    "ColabImage",
    "CometInput",
    "CometInstance",
    "CometResult",
    "CometSpec",
    "CompleteTrialRequest",
    "CompletionStats",
    "ComputationBasedMetricSpec",
    "ComputeTokensRequest",
    "ComputeTokensResponse",
    "ContainerRegistryDestination",
    "ContainerSpec",
    "Content",
    "ContentMap",
    "Context",
    "CopyModelOperationMetadata",
    "CopyModelRequest",
    "CopyModelResponse",
    "CorpusStatus",
    "CorroborateContentRequest",
    "CorroborateContentResponse",
    "CountTokensRequest",
    "CountTokensResponse",
    "CreateArtifactRequest",
    "CreateBatchPredictionJobRequest",
    "CreateCachedContentRequest",
    "CreateContextRequest",
    "CreateCustomJobRequest",
    "CreateDataLabelingJobRequest",
    "CreateDatasetOperationMetadata",
    "CreateDatasetRequest",
    "CreateDatasetVersionOperationMetadata",
    "CreateDatasetVersionRequest",
    "CreateDeploymentResourcePoolOperationMetadata",
    "CreateDeploymentResourcePoolRequest",
    "CreateEndpointOperationMetadata",
    "CreateEndpointRequest",
    "CreateEntityTypeOperationMetadata",
    "CreateEntityTypeRequest",
    "CreateExecutionRequest",
    "CreateFeatureGroupOperationMetadata",
    "CreateFeatureGroupRequest",
    "CreateFeatureOnlineStoreOperationMetadata",
    "CreateFeatureOnlineStoreRequest",
    "CreateFeatureOperationMetadata",
    "CreateFeatureRequest",
    "CreateFeatureViewOperationMetadata",
    "CreateFeatureViewRequest",
    "CreateFeaturestoreOperationMetadata",
    "CreateFeaturestoreRequest",
    "CreateHyperparameterTuningJobRequest",
    "CreateIndexEndpointOperationMetadata",
    "CreateIndexEndpointRequest",
    "CreateIndexOperationMetadata",
    "CreateIndexRequest",
    "CreateMetadataSchemaRequest",
    "CreateMetadataStoreOperationMetadata",
    "CreateMetadataStoreRequest",
    "CreateModelDeploymentMonitoringJobRequest",
    "CreateNasJobRequest",
    "CreateNotebookExecutionJobOperationMetadata",
    "CreateNotebookExecutionJobRequest",
    "CreateNotebookRuntimeTemplateOperationMetadata",
    "CreateNotebookRuntimeTemplateRequest",
    "CreatePersistentResourceOperationMetadata",
    "CreatePersistentResourceRequest",
    "CreatePipelineJobRequest",
    "CreateRagCorpusOperationMetadata",
    "CreateRagCorpusRequest",
    "CreateReasoningEngineOperationMetadata",
    "CreateReasoningEngineRequest",
    "CreateRegistryFeatureOperationMetadata",
    "CreateScheduleRequest",
    "CreateSessionOperationMetadata",
    "CreateSessionRequest",
    "CreateSpecialistPoolOperationMetadata",
    "CreateSpecialistPoolRequest",
    "CreateStudyRequest",
    "CreateTensorboardExperimentRequest",
    "CreateTensorboardOperationMetadata",
    "CreateTensorboardRequest",
    "CreateTensorboardRunRequest",
    "CreateTensorboardTimeSeriesRequest",
    "CreateTrainingPipelineRequest",
    "CreateTrialRequest",
    "CreateTuningJobRequest",
    "CsvDestination",
    "CsvSource",
    "CustomJob",
    "CustomJobSpec",
    "CustomOutput",
    "CustomOutputFormatConfig",
    "DataFoundryServiceClient",
    "DataItem",
    "DataItemView",
    "DataLabelingJob",
    "Dataset",
    "DatasetServiceClient",
    "DatasetVersion",
    "DedicatedResources",
    "DeleteArtifactRequest",
    "DeleteBatchPredictionJobRequest",
    "DeleteCachedContentRequest",
    "DeleteContextRequest",
    "DeleteCustomJobRequest",
    "DeleteDataLabelingJobRequest",
    "DeleteDatasetRequest",
    "DeleteDatasetVersionRequest",
    "DeleteDeploymentResourcePoolRequest",
    "DeleteEndpointRequest",
    "DeleteEntityTypeRequest",
    "DeleteExecutionRequest",
    "DeleteFeatureGroupRequest",
    "DeleteFeatureOnlineStoreRequest",
    "DeleteFeatureRequest",
    "DeleteFeatureValuesOperationMetadata",
    "DeleteFeatureValuesRequest",
    "DeleteFeatureValuesResponse",
    "DeleteFeatureViewRequest",
    "DeleteFeaturestoreRequest",
    "DeleteHyperparameterTuningJobRequest",
    "DeleteIndexEndpointRequest",
    "DeleteIndexRequest",
    "DeleteMetadataStoreOperationMetadata",
    "DeleteMetadataStoreRequest",
    "DeleteModelDeploymentMonitoringJobRequest",
    "DeleteModelRequest",
    "DeleteModelVersionRequest",
    "DeleteNasJobRequest",
    "DeleteNotebookExecutionJobRequest",
    "DeleteNotebookRuntimeRequest",
    "DeleteNotebookRuntimeTemplateRequest",
    "DeleteOperationMetadata",
    "DeletePersistentResourceRequest",
    "DeletePipelineJobRequest",
    "DeleteRagCorpusRequest",
    "DeleteRagFileRequest",
    "DeleteReasoningEngineRequest",
    "DeleteSavedQueryRequest",
    "DeleteScheduleRequest",
    "DeleteSessionRequest",
    "DeleteSpecialistPoolRequest",
    "DeleteStudyRequest",
    "DeleteTensorboardExperimentRequest",
    "DeleteTensorboardRequest",
    "DeleteTensorboardRunRequest",
    "DeleteTensorboardTimeSeriesRequest",
    "DeleteTrainingPipelineRequest",
    "DeleteTrialRequest",
    "DeployIndexOperationMetadata",
    "DeployIndexRequest",
    "DeployIndexResponse",
    "DeployModelOperationMetadata",
    "DeployModelRequest",
    "DeployModelResponse",
    "DeployOperationMetadata",
    "DeployRequest",
    "DeployResponse",
    "DeployedIndex",
    "DeployedIndexAuthConfig",
    "DeployedIndexRef",
    "DeployedModel",
    "DeployedModelRef",
    "DeploymentResourcePool",
    "DeploymentResourcePoolServiceClient",
    "DeploymentStage",
    "DestinationFeatureSetting",
    "DirectPredictRequest",
    "DirectPredictResponse",
    "DirectRawPredictRequest",
    "DirectRawPredictResponse",
    "DirectUploadSource",
    "DiskSpec",
    "DnsPeeringConfig",
    "DoubleArray",
    "DynamicRetrievalConfig",
    "EmbedContentRequest",
    "EmbedContentResponse",
    "EncryptionSpec",
    "Endpoint",
    "EndpointServiceClient",
    "EnterpriseWebSearch",
    "EntityIdSelector",
    "EntityType",
    "EnvVar",
    "ErrorAnalysisAnnotation",
    "EvaluateDatasetResponse",
    "EvaluateDatasetRun",
    "EvaluateInstancesRequest",
    "EvaluateInstancesResponse",
    "EvaluatedAnnotation",
    "EvaluatedAnnotationExplanation",
    "EvaluationConfig",
    "EvaluationDataset",
    "EvaluationServiceClient",
    "Event",
    "EventActions",
    "EventMetadata",
    "ExactMatchInput",
    "ExactMatchInstance",
    "ExactMatchMetricValue",
    "ExactMatchResults",
    "ExactMatchSpec",
    "Examples",
    "ExamplesOverride",
    "ExamplesRestrictionsNamespace",
    "ExecutableCode",
    "Execution",
    "ExplainRequest",
    "ExplainResponse",
    "Explanation",
    "ExplanationMetadata",
    "ExplanationMetadataOverride",
    "ExplanationParameters",
    "ExplanationSpec",
    "ExplanationSpecOverride",
    "ExportDataConfig",
    "ExportDataOperationMetadata",
    "ExportDataRequest",
    "ExportDataResponse",
    "ExportFeatureValuesOperationMetadata",
    "ExportFeatureValuesRequest",
    "ExportFeatureValuesResponse",
    "ExportFilterSplit",
    "ExportFractionSplit",
    "ExportModelOperationMetadata",
    "ExportModelRequest",
    "ExportModelResponse",
    "ExportTensorboardTimeSeriesDataRequest",
    "ExportTensorboardTimeSeriesDataResponse",
    "Fact",
    "FasterDeploymentConfig",
    "Feature",
    "FeatureGroup",
    "FeatureNoiseSigma",
    "FeatureOnlineStore",
    "FeatureOnlineStoreAdminServiceClient",
    "FeatureOnlineStoreServiceClient",
    "FeatureRegistryServiceClient",
    "FeatureSelector",
    "FeatureStatsAnomaly",
    "FeatureValue",
    "FeatureValueDestination",
    "FeatureValueList",
    "FeatureView",
    "FeatureViewDataFormat",
    "FeatureViewDataKey",
    "FeatureViewDirectWriteRequest",
    "FeatureViewDirectWriteResponse",
    "FeatureViewSync",
    "Featurestore",
    "FeaturestoreMonitoringConfig",
    "FeaturestoreOnlineServingServiceClient",
    "FeaturestoreServiceClient",
    "FetchFeatureValuesRequest",
    "FetchFeatureValuesResponse",
    "FileData",
    "FileStatus",
    "FilterSplit",
    "FindNeighborsRequest",
    "FindNeighborsResponse",
    "FluencyInput",
    "FluencyInstance",
    "FluencyResult",
    "FluencySpec",
    "FractionSplit",
    "FulfillmentInput",
    "FulfillmentInstance",
    "FulfillmentResult",
    "FulfillmentSpec",
    "FunctionCall",
    "FunctionCallingConfig",
    "FunctionDeclaration",
    "FunctionResponse",
    "FunctionResponseBlob",
    "FunctionResponseFileData",
    "FunctionResponsePart",
    "GcsDestination",
    "GcsSource",
    "GenAiAdvancedFeaturesConfig",
    "GenAiCacheServiceClient",
    "GenAiTuningServiceClient",
    "GenerateContentRequest",
    "GenerateContentResponse",
    "GenerateFetchAccessTokenRequest",
    "GenerateFetchAccessTokenResponse",
    "GenerateSyntheticDataRequest",
    "GenerateSyntheticDataResponse",
    "GenerationConfig",
    "GenericOperationMetadata",
    "GenieSource",
    "GetAnnotationSpecRequest",
    "GetArtifactRequest",
    "GetBatchPredictionJobRequest",
    "GetCachedContentRequest",
    "GetContextRequest",
    "GetCustomJobRequest",
    "GetDataLabelingJobRequest",
    "GetDatasetRequest",
    "GetDatasetVersionRequest",
    "GetDeploymentResourcePoolRequest",
    "GetEndpointRequest",
    "GetEntityTypeRequest",
    "GetExecutionRequest",
    "GetFeatureGroupRequest",
    "GetFeatureOnlineStoreRequest",
    "GetFeatureRequest",
    "GetFeatureViewRequest",
    "GetFeatureViewSyncRequest",
    "GetFeaturestoreRequest",
    "GetHyperparameterTuningJobRequest",
    "GetIndexEndpointRequest",
    "GetIndexRequest",
    "GetMetadataSchemaRequest",
    "GetMetadataStoreRequest",
    "GetModelDeploymentMonitoringJobRequest",
    "GetModelEvaluationRequest",
    "GetModelEvaluationSliceRequest",
    "GetModelRequest",
    "GetNasJobRequest",
    "GetNasTrialDetailRequest",
    "GetNotebookExecutionJobRequest",
    "GetNotebookRuntimeRequest",
    "GetNotebookRuntimeTemplateRequest",
    "GetPersistentResourceRequest",
    "GetPipelineJobRequest",
    "GetPublisherModelRequest",
    "GetRagCorpusRequest",
    "GetRagEngineConfigRequest",
    "GetRagFileRequest",
    "GetReasoningEngineRequest",
    "GetScheduleRequest",
    "GetSessionRequest",
    "GetSpecialistPoolRequest",
    "GetStudyRequest",
    "GetTensorboardExperimentRequest",
    "GetTensorboardRequest",
    "GetTensorboardRunRequest",
    "GetTensorboardTimeSeriesRequest",
    "GetTrainingPipelineRequest",
    "GetTrialRequest",
    "GetTuningJobRequest",
    "GoogleDriveSource",
    "GoogleMaps",
    "GoogleSearchRetrieval",
    "GroundednessInput",
    "GroundednessInstance",
    "GroundednessResult",
    "GroundednessSpec",
    "GroundingChunk",
    "GroundingMetadata",
    "GroundingSupport",
    "HarmCategory",
    "HyperparameterTuningJob",
    "IdMatcher",
    "ImageConfig",
    "ImportDataConfig",
    "ImportDataOperationMetadata",
    "ImportDataRequest",
    "ImportDataResponse",
    "ImportFeatureValuesOperationMetadata",
    "ImportFeatureValuesRequest",
    "ImportFeatureValuesResponse",
    "ImportModelEvaluationRequest",
    "ImportRagFilesConfig",
    "ImportRagFilesOperationMetadata",
    "ImportRagFilesRequest",
    "ImportRagFilesResponse",
    "Index",
    "IndexDatapoint",
    "IndexEndpoint",
    "IndexEndpointServiceClient",
    "IndexPrivateEndpoints",
    "IndexServiceClient",
    "IndexStats",
    "InputDataConfig",
    "Int64Array",
    "IntegratedGradientsAttribution",
    "JiraSource",
    "JobServiceClient",
    "JobState",
    "LLMBasedMetricSpec",
    "LargeModelReference",
    "LineageSubgraph",
    "ListAnnotationsRequest",
    "ListAnnotationsResponse",
    "ListArtifactsRequest",
    "ListArtifactsResponse",
    "ListBatchPredictionJobsRequest",
    "ListBatchPredictionJobsResponse",
    "ListCachedContentsRequest",
    "ListCachedContentsResponse",
    "ListContextsRequest",
    "ListContextsResponse",
    "ListCustomJobsRequest",
    "ListCustomJobsResponse",
    "ListDataItemsRequest",
    "ListDataItemsResponse",
    "ListDataLabelingJobsRequest",
    "ListDataLabelingJobsResponse",
    "ListDatasetVersionsRequest",
    "ListDatasetVersionsResponse",
    "ListDatasetsRequest",
    "ListDatasetsResponse",
    "ListDeploymentResourcePoolsRequest",
    "ListDeploymentResourcePoolsResponse",
    "ListEndpointsRequest",
    "ListEndpointsResponse",
    "ListEntityTypesRequest",
    "ListEntityTypesResponse",
    "ListEventsRequest",
    "ListEventsResponse",
    "ListExecutionsRequest",
    "ListExecutionsResponse",
    "ListFeatureGroupsRequest",
    "ListFeatureGroupsResponse",
    "ListFeatureOnlineStoresRequest",
    "ListFeatureOnlineStoresResponse",
    "ListFeatureViewSyncsRequest",
    "ListFeatureViewSyncsResponse",
    "ListFeatureViewsRequest",
    "ListFeatureViewsResponse",
    "ListFeaturesRequest",
    "ListFeaturesResponse",
    "ListFeaturestoresRequest",
    "ListFeaturestoresResponse",
    "ListHyperparameterTuningJobsRequest",
    "ListHyperparameterTuningJobsResponse",
    "ListIndexEndpointsRequest",
    "ListIndexEndpointsResponse",
    "ListIndexesRequest",
    "ListIndexesResponse",
    "ListMetadataSchemasRequest",
    "ListMetadataSchemasResponse",
    "ListMetadataStoresRequest",
    "ListMetadataStoresResponse",
    "ListModelDeploymentMonitoringJobsRequest",
    "ListModelDeploymentMonitoringJobsResponse",
    "ListModelEvaluationSlicesRequest",
    "ListModelEvaluationSlicesResponse",
    "ListModelEvaluationsRequest",
    "ListModelEvaluationsResponse",
    "ListModelVersionCheckpointsRequest",
    "ListModelVersionCheckpointsResponse",
    "ListModelVersionsRequest",
    "ListModelVersionsResponse",
    "ListModelsRequest",
    "ListModelsResponse",
    "ListNasJobsRequest",
    "ListNasJobsResponse",
    "ListNasTrialDetailsRequest",
    "ListNasTrialDetailsResponse",
    "ListNotebookExecutionJobsRequest",
    "ListNotebookExecutionJobsResponse",
    "ListNotebookRuntimeTemplatesRequest",
    "ListNotebookRuntimeTemplatesResponse",
    "ListNotebookRuntimesRequest",
    "ListNotebookRuntimesResponse",
    "ListOptimalTrialsRequest",
    "ListOptimalTrialsResponse",
    "ListPersistentResourcesRequest",
    "ListPersistentResourcesResponse",
    "ListPipelineJobsRequest",
    "ListPipelineJobsResponse",
    "ListRagCorporaRequest",
    "ListRagCorporaResponse",
    "ListRagFilesRequest",
    "ListRagFilesResponse",
    "ListReasoningEnginesRequest",
    "ListReasoningEnginesResponse",
    "ListSavedQueriesRequest",
    "ListSavedQueriesResponse",
    "ListSchedulesRequest",
    "ListSchedulesResponse",
    "ListSessionsRequest",
    "ListSessionsResponse",
    "ListSpecialistPoolsRequest",
    "ListSpecialistPoolsResponse",
    "ListStudiesRequest",
    "ListStudiesResponse",
    "ListTensorboardExperimentsRequest",
    "ListTensorboardExperimentsResponse",
    "ListTensorboardRunsRequest",
    "ListTensorboardRunsResponse",
    "ListTensorboardTimeSeriesRequest",
    "ListTensorboardTimeSeriesResponse",
    "ListTensorboardsRequest",
    "ListTensorboardsResponse",
    "ListTrainingPipelinesRequest",
    "ListTrainingPipelinesResponse",
    "ListTrialsRequest",
    "ListTrialsResponse",
    "ListTuningJobsRequest",
    "ListTuningJobsResponse",
    "LlmUtilityServiceClient",
    "LogprobsResult",
    "LookupStudyRequest",
    "LustreMount",
    "MachineSpec",
    "ManualBatchTuningParameters",
    "MatchServiceClient",
    "Measurement",
    "MergeVersionAliasesRequest",
    "MetadataSchema",
    "MetadataServiceClient",
    "MetadataStore",
    "Metric",
    "MetricResult",
    "MetricxInput",
    "MetricxInstance",
    "MetricxResult",
    "MetricxSpec",
    "MigratableResource",
    "MigrateResourceRequest",
    "MigrateResourceResponse",
    "MigrationServiceClient",
    "Modality",
    "ModalityTokenCount",
    "Model",
    "ModelArmorConfig",
    "ModelContainerSpec",
    "ModelDeploymentMonitoringBigQueryTable",
    "ModelDeploymentMonitoringJob",
    "ModelDeploymentMonitoringObjectiveConfig",
    "ModelDeploymentMonitoringObjectiveType",
    "ModelDeploymentMonitoringScheduleConfig",
    "ModelEvaluation",
    "ModelEvaluationSlice",
    "ModelExplanation",
    "ModelGardenServiceClient",
    "ModelGardenSource",
    "ModelMonitoringAlertConfig",
    "ModelMonitoringObjectiveConfig",
    "ModelMonitoringStatsAnomalies",
    "ModelServiceClient",
    "ModelSourceInfo",
    "ModelVersionCheckpoint",
    "MultiSpeakerVoiceConfig",
    "MutateDeployedIndexOperationMetadata",
    "MutateDeployedIndexRequest",
    "MutateDeployedIndexResponse",
    "MutateDeployedModelOperationMetadata",
    "MutateDeployedModelRequest",
    "MutateDeployedModelResponse",
    "NasJob",
    "NasJobOutput",
    "NasJobSpec",
    "NasTrial",
    "NasTrialDetail",
    "NearestNeighborQuery",
    "NearestNeighborSearchOperationMetadata",
    "NearestNeighbors",
    "Neighbor",
    "NetworkSpec",
    "NfsMount",
    "NotebookEucConfig",
    "NotebookExecutionJob",
    "NotebookExecutionJobView",
    "NotebookIdleShutdownConfig",
    "NotebookRuntime",
    "NotebookRuntimeTemplate",
    "NotebookRuntimeTemplateRef",
    "NotebookRuntimeType",
    "NotebookServiceClient",
    "NotebookSoftwareConfig",
    "OutputConfig",
    "OutputFieldSpec",
    "OutputInfo",
    "PSCAutomationConfig",
    "PSCAutomationState",
    "PairwiseChoice",
    "PairwiseMetricInput",
    "PairwiseMetricInstance",
    "PairwiseMetricResult",
    "PairwiseMetricSpec",
    "PairwiseQuestionAnsweringQualityInput",
    "PairwiseQuestionAnsweringQualityInstance",
    "PairwiseQuestionAnsweringQualityResult",
    "PairwiseQuestionAnsweringQualitySpec",
    "PairwiseSummarizationQualityInput",
    "PairwiseSummarizationQualityInstance",
    "PairwiseSummarizationQualityResult",
    "PairwiseSummarizationQualitySpec",
    "Part",
    "PartialArg",
    "PauseModelDeploymentMonitoringJobRequest",
    "PauseScheduleRequest",
    "PersistentDiskSpec",
    "PersistentResource",
    "PersistentResourceServiceClient",
    "PipelineFailurePolicy",
    "PipelineJob",
    "PipelineJobDetail",
    "PipelineServiceClient",
    "PipelineState",
    "PipelineTaskDetail",
    "PipelineTaskExecutorDetail",
    "PipelineTemplateMetadata",
    "PointwiseMetricInput",
    "PointwiseMetricInstance",
    "PointwiseMetricResult",
    "PointwiseMetricSpec",
    "Port",
    "PostStartupScriptConfig",
    "PreTunedModel",
    "PrebuiltVoiceConfig",
    "PredefinedMetricSpec",
    "PredefinedSplit",
    "PredictRequest",
    "PredictRequestResponseLoggingConfig",
    "PredictResponse",
    "PredictSchemata",
    "PredictionServiceClient",
    "Presets",
    "PrivateEndpoints",
    "PrivateServiceConnectConfig",
    "Probe",
    "PscAutomatedEndpoints",
    "PscInterfaceConfig",
    "PublisherModel",
    "PublisherModelView",
    "PurgeArtifactsMetadata",
    "PurgeArtifactsRequest",
    "PurgeArtifactsResponse",
    "PurgeContextsMetadata",
    "PurgeContextsRequest",
    "PurgeContextsResponse",
    "PurgeExecutionsMetadata",
    "PurgeExecutionsRequest",
    "PurgeExecutionsResponse",
    "PythonPackageSpec",
    "QueryArtifactLineageSubgraphRequest",
    "QueryContextLineageSubgraphRequest",
    "QueryDeployedModelsRequest",
    "QueryDeployedModelsResponse",
    "QueryExecutionInputsAndOutputsRequest",
    "QueryReasoningEngineRequest",
    "QueryReasoningEngineResponse",
    "QuestionAnsweringCorrectnessInput",
    "QuestionAnsweringCorrectnessInstance",
    "QuestionAnsweringCorrectnessResult",
    "QuestionAnsweringCorrectnessSpec",
    "QuestionAnsweringHelpfulnessInput",
    "QuestionAnsweringHelpfulnessInstance",
    "QuestionAnsweringHelpfulnessResult",
    "QuestionAnsweringHelpfulnessSpec",
    "QuestionAnsweringQualityInput",
    "QuestionAnsweringQualityInstance",
    "QuestionAnsweringQualityResult",
    "QuestionAnsweringQualitySpec",
    "QuestionAnsweringRelevanceInput",
    "QuestionAnsweringRelevanceInstance",
    "QuestionAnsweringRelevanceResult",
    "QuestionAnsweringRelevanceSpec",
    "RagChunk",
    "RagContexts",
    "RagCorpus",
    "RagEmbeddingModelConfig",
    "RagEngineConfig",
    "RagFile",
    "RagFileChunkingConfig",
    "RagFileParsingConfig",
    "RagFileTransformationConfig",
    "RagManagedDbConfig",
    "RagQuery",
    "RagRetrievalConfig",
    "RagVectorDbConfig",
    "RawOutput",
    "RawPredictRequest",
    "RayLogsSpec",
    "RayMetricSpec",
    "RaySpec",
    "ReadFeatureValuesRequest",
    "ReadFeatureValuesResponse",
    "ReadIndexDatapointsRequest",
    "ReadIndexDatapointsResponse",
    "ReadTensorboardBlobDataRequest",
    "ReadTensorboardBlobDataResponse",
    "ReadTensorboardSizeRequest",
    "ReadTensorboardSizeResponse",
    "ReadTensorboardTimeSeriesDataRequest",
    "ReadTensorboardTimeSeriesDataResponse",
    "ReadTensorboardUsageRequest",
    "ReadTensorboardUsageResponse",
    "ReasoningEngine",
    "ReasoningEngineExecutionServiceClient",
    "ReasoningEngineServiceClient",
    "ReasoningEngineSpec",
    "RebaseTunedModelOperationMetadata",
    "RebaseTunedModelRequest",
    "RebootPersistentResourceOperationMetadata",
    "RebootPersistentResourceRequest",
    "RemoveContextChildrenRequest",
    "RemoveContextChildrenResponse",
    "RemoveDatapointsRequest",
    "RemoveDatapointsResponse",
    "ReplicatedVoiceConfig",
    "ReservationAffinity",
    "ResourcePool",
    "ResourceRuntime",
    "ResourceRuntimeSpec",
    "ResourcesConsumed",
    "RestoreDatasetVersionOperationMetadata",
    "RestoreDatasetVersionRequest",
    "ResumeModelDeploymentMonitoringJobRequest",
    "ResumeScheduleRequest",
    "Retrieval",
    "RetrievalConfig",
    "RetrievalMetadata",
    "RetrieveContextsRequest",
    "RetrieveContextsResponse",
    "RougeInput",
    "RougeInstance",
    "RougeMetricValue",
    "RougeResults",
    "RougeSpec",
    "SafetyInput",
    "SafetyInstance",
    "SafetyRating",
    "SafetyResult",
    "SafetySetting",
    "SafetySpec",
    "SampleConfig",
    "SampledShapleyAttribution",
    "SamplingStrategy",
    "SavedQuery",
    "Scalar",
    "Schedule",
    "ScheduleServiceClient",
    "Scheduling",
    "Schema",
    "SearchDataItemsRequest",
    "SearchDataItemsResponse",
    "SearchEntryPoint",
    "SearchFeaturesRequest",
    "SearchFeaturesResponse",
    "SearchMigratableResourcesRequest",
    "SearchMigratableResourcesResponse",
    "SearchModelDeploymentMonitoringStatsAnomaliesRequest",
    "SearchModelDeploymentMonitoringStatsAnomaliesResponse",
    "SearchNearestEntitiesRequest",
    "SearchNearestEntitiesResponse",
    "SecretEnvVar",
    "SecretRef",
    "Segment",
    "ServiceAccountSpec",
    "Session",
    "SessionEvent",
    "SessionServiceClient",
    "SharePointSources",
    "ShieldedVmConfig",
    "SlackSource",
    "SmoothGradConfig",
    "SpeakerVoiceConfig",
    "SpecialistPool",
    "SpecialistPoolServiceClient",
    "SpeculativeDecodingSpec",
    "SpeechConfig",
    "StartNotebookRuntimeOperationMetadata",
    "StartNotebookRuntimeRequest",
    "StartNotebookRuntimeResponse",
    "StopNotebookRuntimeOperationMetadata",
    "StopNotebookRuntimeRequest",
    "StopNotebookRuntimeResponse",
    "StopTrialRequest",
    "StratifiedSplit",
    "StreamDirectPredictRequest",
    "StreamDirectPredictResponse",
    "StreamDirectRawPredictRequest",
    "StreamDirectRawPredictResponse",
    "StreamQueryReasoningEngineRequest",
    "StreamRawPredictRequest",
    "StreamingPredictRequest",
    "StreamingPredictResponse",
    "StreamingRawPredictRequest",
    "StreamingRawPredictResponse",
    "StreamingReadFeatureValuesRequest",
    "StringArray",
    "StructFieldValue",
    "StructValue",
    "Study",
    "StudySpec",
    "StudyTimeConstraint",
    "SuggestTrialsMetadata",
    "SuggestTrialsRequest",
    "SuggestTrialsResponse",
    "SummarizationHelpfulnessInput",
    "SummarizationHelpfulnessInstance",
    "SummarizationHelpfulnessResult",
    "SummarizationHelpfulnessSpec",
    "SummarizationQualityInput",
    "SummarizationQualityInstance",
    "SummarizationQualityResult",
    "SummarizationQualitySpec",
    "SummarizationVerbosityInput",
    "SummarizationVerbosityInstance",
    "SummarizationVerbosityResult",
    "SummarizationVerbositySpec",
    "SupervisedHyperParameters",
    "SupervisedTuningDataStats",
    "SupervisedTuningDatasetDistribution",
    "SupervisedTuningSpec",
    "SyncFeatureViewRequest",
    "SyncFeatureViewResponse",
    "SyntheticExample",
    "SyntheticField",
    "TFRecordDestination",
    "TaskDescriptionStrategy",
    "Tensor",
    "Tensorboard",
    "TensorboardBlob",
    "TensorboardBlobSequence",
    "TensorboardExperiment",
    "TensorboardRun",
    "TensorboardServiceClient",
    "TensorboardTensor",
    "TensorboardTimeSeries",
    "ThresholdConfig",
    "TimeSeriesData",
    "TimeSeriesDataPoint",
    "TimestampSplit",
    "TokensInfo",
    "Tool",
    "ToolCallValidInput",
    "ToolCallValidInstance",
    "ToolCallValidMetricValue",
    "ToolCallValidResults",
    "ToolCallValidSpec",
    "ToolConfig",
    "ToolNameMatchInput",
    "ToolNameMatchInstance",
    "ToolNameMatchMetricValue",
    "ToolNameMatchResults",
    "ToolNameMatchSpec",
    "ToolParameterKVMatchInput",
    "ToolParameterKVMatchInstance",
    "ToolParameterKVMatchMetricValue",
    "ToolParameterKVMatchResults",
    "ToolParameterKVMatchSpec",
    "ToolParameterKeyMatchInput",
    "ToolParameterKeyMatchInstance",
    "ToolParameterKeyMatchMetricValue",
    "ToolParameterKeyMatchResults",
    "ToolParameterKeyMatchSpec",
    "TrainingConfig",
    "TrainingPipeline",
    "Transcription",
    "Trial",
    "TrialContext",
    "TunedModel",
    "TunedModelCheckpoint",
    "TunedModelRef",
    "TuningDataStats",
    "TuningJob",
    "Type",
    "UndeployIndexOperationMetadata",
    "UndeployIndexRequest",
    "UndeployIndexResponse",
    "UndeployModelOperationMetadata",
    "UndeployModelRequest",
    "UndeployModelResponse",
    "UnmanagedContainerModel",
    "UpdateArtifactRequest",
    "UpdateCachedContentRequest",
    "UpdateContextRequest",
    "UpdateDatasetRequest",
    "UpdateDatasetVersionRequest",
    "UpdateDeploymentResourcePoolOperationMetadata",
    "UpdateDeploymentResourcePoolRequest",
    "UpdateEndpointLongRunningRequest",
    "UpdateEndpointOperationMetadata",
    "UpdateEndpointRequest",
    "UpdateEntityTypeRequest",
    "UpdateExecutionRequest",
    "UpdateExplanationDatasetOperationMetadata",
    "UpdateExplanationDatasetRequest",
    "UpdateExplanationDatasetResponse",
    "UpdateFeatureGroupOperationMetadata",
    "UpdateFeatureGroupRequest",
    "UpdateFeatureOnlineStoreOperationMetadata",
    "UpdateFeatureOnlineStoreRequest",
    "UpdateFeatureOperationMetadata",
    "UpdateFeatureRequest",
    "UpdateFeatureViewOperationMetadata",
    "UpdateFeatureViewRequest",
    "UpdateFeaturestoreOperationMetadata",
    "UpdateFeaturestoreRequest",
    "UpdateIndexEndpointRequest",
    "UpdateIndexOperationMetadata",
    "UpdateIndexRequest",
    "UpdateModelDeploymentMonitoringJobOperationMetadata",
    "UpdateModelDeploymentMonitoringJobRequest",
    "UpdateModelRequest",
    "UpdateNotebookRuntimeTemplateRequest",
    "UpdatePersistentResourceOperationMetadata",
    "UpdatePersistentResourceRequest",
    "UpdateRagCorpusOperationMetadata",
    "UpdateRagCorpusRequest",
    "UpdateRagEngineConfigOperationMetadata",
    "UpdateRagEngineConfigRequest",
    "UpdateReasoningEngineOperationMetadata",
    "UpdateReasoningEngineRequest",
    "UpdateScheduleRequest",
    "UpdateSessionRequest",
    "UpdateSpecialistPoolOperationMetadata",
    "UpdateSpecialistPoolRequest",
    "UpdateTensorboardExperimentRequest",
    "UpdateTensorboardOperationMetadata",
    "UpdateTensorboardRequest",
    "UpdateTensorboardRunRequest",
    "UpdateTensorboardTimeSeriesRequest",
    "UpgradeNotebookRuntimeOperationMetadata",
    "UpgradeNotebookRuntimeRequest",
    "UpgradeNotebookRuntimeResponse",
    "UploadModelOperationMetadata",
    "UploadModelRequest",
    "UploadModelResponse",
    "UploadRagFileConfig",
    "UploadRagFileRequest",
    "UploadRagFileResponse",
    "UpsertDatapointsRequest",
    "UpsertDatapointsResponse",
    "UrlContext",
    "UrlContextMetadata",
    "UrlMetadata",
    "UsageMetadata",
    "UserActionReference",
    "Value",
    "VertexAISearch",
    "VertexAiSearchConfig",
    "VertexMultimodalDatasetDestination",
    "VertexMultimodalDatasetSource",
    "VertexRagDataServiceClient",
    "VertexRagServiceClient",
    "VertexRagStore",
    "VideoMetadata",
    "VizierServiceClient",
    "VoiceConfig",
    "WorkerPoolSpec",
    "WriteFeatureValuesPayload",
    "WriteFeatureValuesRequest",
    "WriteFeatureValuesResponse",
    "WriteTensorboardExperimentDataRequest",
    "WriteTensorboardExperimentDataResponse",
    "WriteTensorboardRunDataRequest",
    "WriteTensorboardRunDataResponse",
    "XraiAttribution",
)
